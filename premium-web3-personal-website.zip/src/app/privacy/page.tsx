"use client";
import { useTheme } from "@/lib/theme-context";

export default function PrivacyPage() {
  const { theme } = useTheme();
  const isDark = theme === "cyber";
  const textPrimary = isDark ? "text-white" : "text-slate-900";
  const textSecondary = isDark ? "text-gray-400" : "text-gray-600";

  return (
    <div className={`min-h-screen pt-24 pb-16 ${isDark ? "bg-bg-dark" : "bg-gray-50"}`}>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        <h1 className={`text-4xl font-bold font-[family-name:var(--font-space)] mb-8 ${textPrimary}`}>Privacy Policy</h1>
        <div className={`prose prose-lg max-w-none ${isDark ? "prose-invert" : ""}`}>
          {[
            { title: "1. Information We Collect", content: "We collect information you provide directly to us, including your name, email address, Telegram handle, and any messages you send through our contact forms. We also automatically collect certain technical information when you visit our website, including IP address, browser type, and usage data." },
            { title: "2. How We Use Your Information", content: "We use the information we collect to respond to your inquiries, provide our services, send newsletters (if subscribed), improve our website, and comply with legal obligations. We never sell your personal information to third parties." },
            { title: "3. Data Storage & Security", content: "Your data is stored securely using industry-standard encryption. We implement appropriate technical and organizational measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction." },
            { title: "4. Cookies", content: "We use essential cookies to ensure the proper functioning of our website. Analytics cookies may be used to understand how visitors interact with our site. You can control cookie settings through your browser preferences." },
            { title: "5. Third-Party Services", content: "We may use third-party services such as analytics providers, email services, and scheduling tools. These services have their own privacy policies governing the use of your information." },
            { title: "6. Your Rights", content: "You have the right to access, correct, or delete your personal information. You may also opt out of marketing communications at any time. Contact us at hello@mahfuz.io to exercise your rights." },
            { title: "7. Changes to This Policy", content: "We may update this privacy policy from time to time. We will notify you of any changes by posting the new policy on this page with an updated revision date." },
            { title: "8. Contact Us", content: "If you have any questions about this privacy policy, please contact us at hello@mahfuz.io or via Telegram @mahfuzallum." },
          ].map((s, i) => (
            <div key={i} className="mb-8">
              <h2 className={`text-xl font-bold font-[family-name:var(--font-space)] mb-3 ${textPrimary}`}>{s.title}</h2>
              <p className={textSecondary}>{s.content}</p>
            </div>
          ))}
          <p className={`text-sm ${isDark ? "text-gray-500" : "text-gray-400"}`}>Last updated: March 2025</p>
        </div>
      </div>
    </div>
  );
}
