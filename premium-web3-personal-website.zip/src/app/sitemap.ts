import type { MetadataRoute } from "next";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = "https://mahfuz.io";
  const pages = [
    "", "/about", "/services", "/portfolio", "/dashboard",
    "/blog", "/resources", "/media-kit", "/contact",
    "/privacy", "/terms",
  ];
  return pages.map((path) => ({
    url: `${base}${path}`,
    lastModified: new Date(),
    changeFrequency: path === "" ? "weekly" : "monthly",
    priority: path === "" ? 1 : 0.8,
  }));
}
