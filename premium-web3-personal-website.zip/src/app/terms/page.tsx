"use client";
import { useTheme } from "@/lib/theme-context";

export default function TermsPage() {
  const { theme } = useTheme();
  const isDark = theme === "cyber";
  const textPrimary = isDark ? "text-white" : "text-slate-900";
  const textSecondary = isDark ? "text-gray-400" : "text-gray-600";

  return (
    <div className={`min-h-screen pt-24 pb-16 ${isDark ? "bg-bg-dark" : "bg-gray-50"}`}>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        <h1 className={`text-4xl font-bold font-[family-name:var(--font-space)] mb-8 ${textPrimary}`}>Terms of Service</h1>
        <div className={`prose prose-lg max-w-none ${isDark ? "prose-invert" : ""}`}>
          {[
            { title: "1. Acceptance of Terms", content: "By accessing and using this website, you accept and agree to be bound by the terms and provision of this agreement. If you do not agree to abide by these terms, please do not use this service." },
            { title: "2. Services", content: "Mahfuz provides Web3 growth services including KOL marketing, business development, community growth, and related consulting services. Specific terms for individual engagements will be agreed upon separately." },
            { title: "3. Intellectual Property", content: "All content on this website, including text, graphics, logos, and data, is the property of Mahfuz and protected by applicable intellectual property laws. You may not reproduce, distribute, or create derivative works without explicit permission." },
            { title: "4. User Responsibilities", content: "You agree to use this website only for lawful purposes and in a way that does not infringe upon the rights of others. You are responsible for maintaining the confidentiality of any account information." },
            { title: "5. Disclaimer", content: "The information provided on this website is for general informational purposes only. Nothing on this website constitutes financial, investment, or legal advice. Cryptocurrency investments carry significant risk." },
            { title: "6. Limitation of Liability", content: "Mahfuz shall not be liable for any indirect, incidental, special, or consequential damages arising out of or in connection with the use of this website or services." },
            { title: "7. Privacy", content: "Your use of this website is also governed by our Privacy Policy. Please review our Privacy Policy for information on how we collect, use, and protect your data." },
            { title: "8. Modifications", content: "We reserve the right to modify these terms at any time. Changes will be effective immediately upon posting on this page. Your continued use of the website constitutes acceptance of the modified terms." },
            { title: "9. Contact", content: "For questions about these terms, please contact us at hello@mahfuz.io or via Telegram @mahfuzallum." },
          ].map((s, i) => (
            <div key={i} className="mb-8">
              <h2 className={`text-xl font-bold font-[family-name:var(--font-space)] mb-3 ${textPrimary}`}>{s.title}</h2>
              <p className={textSecondary}>{s.content}</p>
            </div>
          ))}
          <p className={`text-sm ${isDark ? "text-gray-500" : "text-gray-400"}`}>Last updated: March 2025</p>
        </div>
      </div>
    </div>
  );
}
