"use client";
import { Award, Globe, Users, TrendingUp, Shield, Target, Zap, ChevronRight } from "lucide-react";
import Link from "next/link";
import SectionHeader from "@/components/SectionHeader";
import AnimatedCounter from "@/components/AnimatedCounter";
import { useTheme } from "@/lib/theme-context";

export default function AboutPage() {
  const { theme } = useTheme();
  const isDark = theme === "cyber";
  const cardClass = isDark ? "glass rounded-2xl p-6" : "bg-white rounded-2xl p-6 shadow-lg border border-gray-100";
  const textPrimary = isDark ? "text-white" : "text-slate-900";
  const textSecondary = isDark ? "text-gray-400" : "text-gray-600";

  return (
    <div className={`min-h-screen pt-24 pb-16 ${isDark ? "bg-bg-dark" : "bg-gray-50"}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Hero */}
        <div className="text-center mb-20 pt-8">
          <span className="inline-block px-4 py-1.5 rounded-full text-xs font-semibold tracking-wider uppercase bg-brand/10 text-brand border border-brand/20 mb-4">About Me</span>
          <h1 className={`text-4xl md:text-5xl lg:text-6xl font-bold font-[family-name:var(--font-space)] mb-6 ${textPrimary}`}>
            Your <span className="gradient-text">Web3 Growth</span> Partner
          </h1>
          <p className={`text-lg max-w-3xl mx-auto ${textSecondary}`}>
            I&apos;m Mahfuz — a Web3 Growth Partner, KOL, Business Development Manager, Community Builder, Affiliate Marketer, and Content Creator.
            I help blockchain projects, exchanges, and Web3 communities scale through strategic marketing, partnerships, and premium content.
          </p>
        </div>

        {/* Values */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-20">
          {[
            { icon: <Target className="w-6 h-6" />, title: "Results-Driven", desc: "Every campaign is measured by real metrics — trading volume, TVL, community growth, and engagement." },
            { icon: <Shield className="w-6 h-6" />, title: "Trusted Partner", desc: "Worked with 200+ projects including top-tier exchanges, DeFi protocols, and VC-backed startups." },
            { icon: <Globe className="w-6 h-6" />, title: "Global Network", desc: "Connected to 300+ partners, 500+ KOLs, and communities across 50+ countries worldwide." },
            { icon: <Zap className="w-6 h-6" />, title: "Fast Execution", desc: "From strategy to execution in record time. Agile approach with dedicated team support." },
            { icon: <TrendingUp className="w-6 h-6" />, title: "Data-Informed", desc: "Decisions backed by on-chain analytics, market data, and audience insights." },
            { icon: <Award className="w-6 h-6" />, title: "Premium Quality", desc: "Enterprise-grade campaigns with attention to detail that matches top-tier marketing agencies." },
          ].map((v, i) => (
            <div key={i} className={`${cardClass} card-hover`}>
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-brand/20 to-secondary/20 flex items-center justify-center text-brand mb-4">{v.icon}</div>
              <h3 className={`text-lg font-bold font-[family-name:var(--font-space)] mb-2 ${textPrimary}`}>{v.title}</h3>
              <p className={`text-sm ${textSecondary}`}>{v.desc}</p>
            </div>
          ))}
        </div>

        {/* Experience */}
        <SectionHeader badge="Experience" title="My Journey in Web3" subtitle="From early blockchain adoption to becoming one of the most connected growth partners in the industry." />
        <div className="relative max-w-3xl mx-auto mb-20">
          <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-brand to-secondary" />
          {[
            { year: "2019", title: "Entered Crypto", desc: "Started as a community member and quickly grew into managing groups of 50K+ members." },
            { year: "2020", title: "First Major Campaign", desc: "Led a successful exchange listing campaign that generated $500M+ in trading volume." },
            { year: "2021", title: "KOL Network", desc: "Built a network of 300+ KOLs and launched 50+ successful token campaigns." },
            { year: "2022", title: "Global Expansion", desc: "Expanded operations to cover 50+ countries with multilingual marketing capabilities." },
            { year: "2023", title: "Enterprise Clients", desc: "Started working with top-10 exchanges and VC-backed projects with $100M+ valuations." },
            { year: "2024-Present", title: "Full-Service Growth", desc: "Offering end-to-end Web3 growth solutions as a trusted partner for the biggest names in crypto." },
          ].map((e, i) => (
            <div key={i} className={`relative pl-12 md:pl-0 mb-12 ${i % 2 === 0 ? "md:pr-[calc(50%+2rem)] md:text-right" : "md:pl-[calc(50%+2rem)]"}`}>
              <div className={`absolute left-2 md:left-1/2 top-1 w-5 h-5 rounded-full bg-brand border-4 ${isDark ? "border-bg-dark" : "border-gray-50"} -translate-x-1/2 z-10`} />
              <span className="text-brand font-bold font-[family-name:var(--font-space)] text-sm">{e.year}</span>
              <h4 className={`text-lg font-bold mt-1 ${textPrimary}`}>{e.title}</h4>
              <p className={`text-sm mt-1 ${textSecondary}`}>{e.desc}</p>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center">
          <Link href="/contact" className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-brand to-secondary text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-brand/25 transition-all">
            Work With Me <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </div>
  );
}
