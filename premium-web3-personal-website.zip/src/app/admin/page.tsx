"use client";
import { useState, useEffect } from "react";
import { Shield, Users, Mail, MessageCircle, Handshake, BarChart, RefreshCw, Eye } from "lucide-react";

interface DashboardData {
  contacts: number;
  subscribers: number;
  inquiries: number;
  partners: number;
}

export default function AdminPage() {
  const [authed, setAuthed] = useState(false);
  const [pass, setPass] = useState("");
  const [data, setData] = useState<DashboardData | null>(null);
  const [tab, setTab] = useState("overview");
  const [records, setRecords] = useState<Array<Record<string, string | number>>>([]);

  const login = () => {
    if (pass === (process.env.NEXT_PUBLIC_ADMIN_PASS || "admin123")) {
      setAuthed(true);
    }
  };

  const fetchData = async () => {
    try {
      const res = await fetch("/api/admin/stats");
      const d = await res.json();
      setData(d);
    } catch { /* noop */ }
  };

  const fetchRecords = async (type: string) => {
    try {
      const res = await fetch(`/api/admin/${type}`);
      const d = await res.json();
      setRecords(d);
    } catch { /* noop */ }
  };

  useEffect(() => {
    if (authed) fetchData();
  }, [authed]);

  useEffect(() => {
    if (authed && tab !== "overview") fetchRecords(tab);
  }, [authed, tab]);

  if (!authed) {
    return (
      <div className="min-h-screen bg-bg-dark flex items-center justify-center">
        <div className="glass rounded-2xl p-8 max-w-md w-full mx-4">
          <div className="text-center mb-6">
            <Shield className="w-12 h-12 text-brand mx-auto mb-4" />
            <h1 className="text-2xl font-bold font-[family-name:var(--font-space)] text-white">Admin Panel</h1>
            <p className="text-gray-400 text-sm mt-1">Enter your password to continue</p>
          </div>
          <input
            type="password"
            value={pass}
            onChange={e => setPass(e.target.value)}
            onKeyDown={e => e.key === "Enter" && login()}
            placeholder="Password"
            className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder:text-gray-500 focus:outline-none focus:ring-2 focus:ring-brand/50 mb-4"
          />
          <button onClick={login} className="w-full py-3 bg-gradient-to-r from-brand to-secondary text-white font-semibold rounded-xl">
            Login
          </button>
        </div>
      </div>
    );
  }

  const TABS = [
    { id: "overview", label: "Overview", icon: <BarChart className="w-4 h-4" /> },
    { id: "contacts", label: "Contacts", icon: <MessageCircle className="w-4 h-4" /> },
    { id: "newsletter", label: "Newsletter", icon: <Mail className="w-4 h-4" /> },
    { id: "inquiries", label: "Inquiries", icon: <Users className="w-4 h-4" /> },
    { id: "partners", label: "Partners", icon: <Handshake className="w-4 h-4" /> },
  ];

  return (
    <div className="min-h-screen bg-bg-dark pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold font-[family-name:var(--font-space)] text-white">Admin Dashboard</h1>
            <p className="text-gray-400">Manage your website data</p>
          </div>
          <button onClick={fetchData} className="p-3 rounded-xl bg-brand/10 text-brand hover:bg-brand/20 transition-colors">
            <RefreshCw className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
          {TABS.map(t => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${
                tab === t.id ? "bg-brand text-black" : "bg-white/5 text-gray-400 hover:bg-white/10"
              }`}
            >
              {t.icon} {t.label}
            </button>
          ))}
        </div>

        {tab === "overview" && data && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { label: "Contact Messages", value: data.contacts, icon: <MessageCircle className="w-6 h-6" /> },
              { label: "Newsletter Subs", value: data.subscribers, icon: <Mail className="w-6 h-6" /> },
              { label: "Client Inquiries", value: data.inquiries, icon: <Users className="w-6 h-6" /> },
              { label: "Partner Inquiries", value: data.partners, icon: <Handshake className="w-6 h-6" /> },
            ].map((s, i) => (
              <div key={i} className="glass rounded-2xl p-6">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-12 h-12 rounded-xl bg-brand/10 flex items-center justify-center text-brand">{s.icon}</div>
                </div>
                <p className="text-3xl font-bold font-[family-name:var(--font-space)] text-white">{s.value}</p>
                <p className="text-gray-400 text-sm mt-1">{s.label}</p>
              </div>
            ))}
          </div>
        )}

        {tab !== "overview" && (
          <div className="glass rounded-2xl p-6 overflow-x-auto">
            {records.length === 0 ? (
              <p className="text-gray-400 text-center py-8">No records found</p>
            ) : (
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-white/10">
                    {Object.keys(records[0]).map(k => (
                      <th key={k} className="text-left py-3 px-4 text-gray-400 font-medium">{k}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {records.map((r, i) => (
                    <tr key={i} className="border-b border-white/5 hover:bg-white/5">
                      {Object.values(r).map((v, j) => (
                        <td key={j} className="py-3 px-4 text-gray-300 max-w-xs truncate">{String(v)}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
