"use client";
import Link from "next/link";
import { ArrowRight, Star, ExternalLink, Zap, TrendingUp, Users, Building, Send, Mic, Rocket, Coins, PenTool, Megaphone, Handshake, ChevronRight } from "lucide-react";
import AnimatedCounter from "@/components/AnimatedCounter";
import SectionHeader from "@/components/SectionHeader";
import { SERVICES, PORTFOLIO, STATS, TESTIMONIALS } from "@/lib/constants";
import { useI18n } from "@/lib/i18n-context";
import { useTheme } from "@/lib/theme-context";

const ICON_MAP: Record<string, React.ReactNode> = {
  megaphone: <Megaphone className="w-6 h-6" />,
  handshake: <Handshake className="w-6 h-6" />,
  building: <Building className="w-6 h-6" />,
  users: <Users className="w-6 h-6" />,
  send: <Send className="w-6 h-6" />,
  twitter: <ExternalLink className="w-6 h-6" />,
  star: <Star className="w-6 h-6" />,
  mic: <Mic className="w-6 h-6" />,
  rocket: <Rocket className="w-6 h-6" />,
  coins: <Coins className="w-6 h-6" />,
  trendingUp: <TrendingUp className="w-6 h-6" />,
  penTool: <PenTool className="w-6 h-6" />,
};

export default function HomePage() {
  const { t } = useI18n();
  const { theme } = useTheme();
  const isDark = theme === "cyber";

  return (
    <>
      {/* Hero */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Background Effects */}
        <div className="absolute inset-0 hero-gradient" />
        <div className="absolute inset-0 animate-grid" />
        {/* Floating orbs */}
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-brand/10 rounded-full blur-[100px] animate-float" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-secondary/10 rounded-full blur-[120px] animate-float" style={{ animationDelay: "3s" }} />
        {/* Floating icons */}
        <div className="absolute top-1/3 left-[15%] text-4xl animate-float opacity-30" style={{ animationDelay: "1s" }}>₿</div>
        <div className="absolute top-1/4 right-[20%] text-3xl animate-float opacity-30" style={{ animationDelay: "2s" }}>Ξ</div>
        <div className="absolute bottom-1/3 left-[25%] text-3xl animate-float opacity-20" style={{ animationDelay: "4s" }}>◎</div>

        <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-32 pb-20">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-brand/10 border border-brand/20 text-brand text-sm font-medium mb-8">
            <Zap className="w-4 h-4" />
            <span>Web3 Growth Partner</span>
          </div>

          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold font-[family-name:var(--font-space)] text-white mb-6 leading-tight">
            {t("hero_title").split("Grow Faster").map((part, i, arr) =>
              i < arr.length - 1 ? (
                <span key={i}>{part}<span className="gradient-text">Grow Faster</span></span>
              ) : (
                <span key={i}>{part}</span>
              )
            )}
          </h1>

          <p className="text-lg md:text-xl text-gray-400 max-w-3xl mx-auto mb-10 leading-relaxed">
            {t("hero_sub")}
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
            <Link href="/contact" className="group px-8 py-4 bg-gradient-to-r from-brand to-secondary text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-brand/25 transition-all flex items-center justify-center gap-2">
              {t("book_call")}
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Link>
            <Link href="/portfolio" className="px-8 py-4 bg-white/5 border border-white/10 text-white font-semibold rounded-xl hover:bg-white/10 transition-all flex items-center justify-center gap-2">
              {t("view_portfolio")}
            </Link>
            <Link href="/media-kit" className="px-8 py-4 bg-white/5 border border-white/10 text-white font-semibold rounded-xl hover:bg-white/10 transition-all flex items-center justify-center gap-2">
              {t("download_media")}
            </Link>
          </div>

          {/* Trusted by */}
          <div className="flex flex-wrap justify-center gap-8 opacity-50">
            {["Binance", "OKX", "Bybit", "Gate.io", "KuCoin", "MEXC"].map((name) => (
              <span key={name} className="text-gray-500 text-sm font-medium">{name}</span>
            ))}
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className={`py-20 ${isDark ? "bg-card-dark/50" : "bg-gray-50"}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8">
            {STATS.map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="text-3xl md:text-4xl font-bold font-[family-name:var(--font-space)] gradient-text mb-2">
                  <AnimatedCounter value={stat.value} suffix={stat.suffix} />
                </div>
                <div className={`text-sm ${isDark ? "text-gray-400" : "text-gray-600"}`}>{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services */}
      <section className={`py-24 ${isDark ? "bg-bg-dark" : "bg-white"}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader badge="Services" title="Web3 Growth Solutions" subtitle="Comprehensive marketing and growth services designed for blockchain projects, exchanges, and Web3 communities." />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {SERVICES.slice(0, 6).map((svc) => (
              <div key={svc.title} className={`group p-6 rounded-2xl card-hover ${isDark ? "gradient-border" : "gradient-border-light"}`}>
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-brand/20 to-secondary/20 flex items-center justify-center text-brand mb-4 group-hover:scale-110 transition-transform">
                  {ICON_MAP[svc.icon] || <Zap className="w-6 h-6" />}
                </div>
                <h3 className={`text-lg font-bold font-[family-name:var(--font-space)] mb-2 ${isDark ? "text-white" : "text-slate-900"}`}>{svc.title}</h3>
                <p className={`text-sm mb-4 ${isDark ? "text-gray-400" : "text-gray-600"}`}>{svc.desc}</p>
                <span className="text-brand text-sm font-semibold">{svc.stats}</span>
              </div>
            ))}
          </div>
          <div className="text-center mt-10">
            <Link href="/services" className="inline-flex items-center gap-2 text-brand font-semibold hover:gap-3 transition-all">
              View All Services <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Portfolio */}
      <section className={`py-24 ${isDark ? "bg-card-dark/30" : "bg-gray-50"}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader badge="Portfolio" title="Projects & Results" subtitle="Real results from real campaigns. Every project is backed by data and measurable outcomes." />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {PORTFOLIO.slice(0, 3).map((p) => (
              <div key={p.name} className={`p-6 rounded-2xl card-hover ${isDark ? "glass" : "bg-white shadow-lg shadow-gray-200/50 border border-gray-100"}`}>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-brand to-secondary flex items-center justify-center text-white font-bold text-lg">
                    {p.name[0]}
                  </div>
                  <div>
                    <h3 className={`font-bold ${isDark ? "text-white" : "text-slate-900"}`}>{p.name}</h3>
                    <span className="text-brand text-xs font-medium">{p.category}</span>
                  </div>
                </div>
                <p className={`text-sm mb-4 ${isDark ? "text-gray-400" : "text-gray-600"}`}>{p.goal}</p>
                <div className={`text-sm font-semibold mb-4 ${isDark ? "text-neon-green" : "text-emerald-600"}`}>✓ {p.result}</div>
                <div className="flex gap-4 mb-4">
                  <div><span className={`block text-xs ${isDark ? "text-gray-500" : "text-gray-400"}`}>Reach</span><span className={`text-sm font-bold ${isDark ? "text-white" : "text-slate-900"}`}>{p.reach}</span></div>
                  <div><span className={`block text-xs ${isDark ? "text-gray-500" : "text-gray-400"}`}>Engagement</span><span className={`text-sm font-bold ${isDark ? "text-white" : "text-slate-900"}`}>{p.engagement}</span></div>
                </div>
                <p className={`text-xs italic ${isDark ? "text-gray-500" : "text-gray-400"}`}>&ldquo;{p.feedback}&rdquo;</p>
              </div>
            ))}
          </div>
          <div className="text-center mt-10">
            <Link href="/portfolio" className="inline-flex items-center gap-2 text-brand font-semibold hover:gap-3 transition-all">
              View Full Portfolio <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className={`py-24 ${isDark ? "bg-bg-dark" : "bg-white"}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader badge="Testimonials" title="What Clients Say" subtitle="Don't just take my word for it. Here's what industry leaders say about working with me." />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {TESTIMONIALS.map((t, i) => (
              <div key={i} className={`p-6 rounded-2xl card-hover ${isDark ? "glass" : "bg-white shadow-lg shadow-gray-200/50 border border-gray-100"}`}>
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: t.rating }).map((_, j) => (
                    <Star key={j} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                  ))}
                </div>
                <p className={`mb-4 ${isDark ? "text-gray-300" : "text-gray-700"}`}>&ldquo;{t.text}&rdquo;</p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-brand to-secondary flex items-center justify-center text-white text-sm font-bold">
                    {t.name.split(" ").map(n => n[0]).join("")}
                  </div>
                  <div>
                    <p className={`text-sm font-semibold ${isDark ? "text-white" : "text-slate-900"}`}>{t.name}</p>
                    <p className={`text-xs ${isDark ? "text-gray-500" : "text-gray-400"}`}>{t.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 hero-gradient" />
        <div className="absolute inset-0 animate-grid" />
        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-5xl font-bold font-[family-name:var(--font-space)] text-white mb-6">
            Ready to <span className="gradient-text">Scale Your Project</span>?
          </h2>
          <p className="text-lg text-gray-400 mb-10 max-w-2xl mx-auto">
            Let&apos;s discuss how we can drive growth for your Web3 project through strategic marketing, partnerships, and community building.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact" className="group px-8 py-4 bg-gradient-to-r from-brand to-secondary text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-brand/25 transition-all flex items-center justify-center gap-2">
              Book a Call
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Link>
            <Link href="/dashboard" className="px-8 py-4 bg-white/5 border border-white/10 text-white font-semibold rounded-xl hover:bg-white/10 transition-all">
              Explore Dashboard
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
