"use client";
import { useEffect, useState } from "react";
import { TrendingUp, TrendingDown, Activity, Fuel, AlertTriangle, Calendar, Rocket, Gift, Globe, Newspaper, ExternalLink, RefreshCw } from "lucide-react";
import SectionHeader from "@/components/SectionHeader";
import { useTheme } from "@/lib/theme-context";

interface CoinData {
  id: string; symbol: string; name: string; current_price: number;
  market_cap: number; price_change_percentage_24h: number; total_volume: number; image: string;
}

interface FearGreedEntry { value: string; value_classification: string; timestamp: string; }
interface NewsItem { title: string; description: string; source: string; publishedAt: string; url: string; category: string; }

const TOKEN_UNLOCKS = [
  { project: "Arbitrum", symbol: "ARB", unlockPct: 3.49, value: "$420M", date: "2025-03-16", countdown: "Upcoming" },
  { project: "Optimism", symbol: "OP", unlockPct: 2.75, value: "$180M", date: "2025-03-31", countdown: "2 weeks" },
  { project: "Aptos", symbol: "APT", unlockPct: 2.12, value: "$250M", date: "2025-04-12", countdown: "1 month" },
  { project: "Sui", symbol: "SUI", unlockPct: 4.0, value: "$310M", date: "2025-04-15", countdown: "1 month" },
];

const IDO_CALENDAR = [
  { token: "MetaVerse AI", launchpad: "Binance Launchpad", date: "2025-03-20", status: "Upcoming" },
  { token: "DeFi Shield", launchpad: "ByBit Launchpad", date: "2025-03-22", status: "Upcoming" },
  { token: "ChainGPT", launchpad: "Gate.io Startup", date: "2025-03-25", status: "Open" },
  { token: "GameFi World", launchpad: "KuCoin Spotlight", date: "2025-04-01", status: "Upcoming" },
];

const AIRDROPS = [
  { name: "LayerZero Season 2", reward: "ZRO Tokens", difficulty: "Medium", deadline: "Q2 2025", status: "Active" },
  { name: "zkSync Era", reward: "ZK Tokens", difficulty: "Easy", deadline: "Q2 2025", status: "Active" },
  { name: "Scroll", reward: "SCR Tokens", difficulty: "Hard", deadline: "Q3 2025", status: "Upcoming" },
  { name: "Berachain", reward: "BERA Tokens", difficulty: "Medium", deadline: "Q2 2025", status: "Active" },
];

const WHALE_ALERTS = [
  { amount: "2,500 BTC", coin: "Bitcoin", from: "Unknown Wallet", to: "Coinbase", time: "2 min ago", value: "$168M" },
  { amount: "45,000 ETH", coin: "Ethereum", from: "Binance", to: "Unknown Wallet", time: "15 min ago", value: "$155M" },
  { amount: "1.2M SOL", coin: "Solana", from: "FTX Estate", to: "Galaxy Digital", time: "1 hr ago", value: "$210M" },
  { amount: "500M USDT", coin: "Tether", from: "Tether Treasury", to: "Bitfinex", time: "2 hr ago", value: "$500M" },
];

const GAS_DATA = {
  ethereum: { low: 12, avg: 18, high: 35 },
  bsc: { low: 3, avg: 5, high: 8 },
  solana: { low: 0.00025, avg: 0.0005, high: 0.001 },
};

function fmt(n: number) {
  if (n >= 1e12) return `$${(n / 1e12).toFixed(2)}T`;
  if (n >= 1e9) return `$${(n / 1e9).toFixed(2)}B`;
  if (n >= 1e6) return `$${(n / 1e6).toFixed(2)}M`;
  return `$${n.toLocaleString()}`;
}

export default function DashboardPage() {
  const { theme } = useTheme();
  const isDark = theme === "cyber";
  const [coins, setCoins] = useState<CoinData[]>([]);
  const [fearGreed, setFearGreed] = useState<FearGreedEntry[]>([]);
  const [news, setNews] = useState<NewsItem[]>([]);
  const [globalData, setGlobalData] = useState<{ total_market_cap?: { usd?: number }; total_volume?: { usd?: number }; market_cap_percentage?: { btc?: number; eth?: number } } | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchAll = async () => {
    setLoading(true);
    try {
      const [pricesRes, fgRes, newsRes, globalRes] = await Promise.all([
        fetch("/api/crypto/prices"), fetch("/api/crypto/fear-greed"), fetch("/api/crypto/news"), fetch("/api/crypto/global"),
      ]);
      const pricesData = await pricesRes.json();
      const fgData = await fgRes.json();
      const newsData = await newsRes.json();
      const globalJsonData = await globalRes.json();
      setCoins(pricesData);
      setFearGreed(fgData.data || []);
      setNews(newsData);
      setGlobalData(globalJsonData.data || globalJsonData);
    } catch { /* fallback */ }
    setLoading(false);
  };

  useEffect(() => { fetchAll(); }, []);

  const fgValue = fearGreed[0] ? parseInt(fearGreed[0].value) : 50;
  const fgLabel = fearGreed[0]?.value_classification || "Neutral";
  const fgColor = fgValue <= 25 ? "text-red-500" : fgValue <= 45 ? "text-orange-500" : fgValue <= 55 ? "text-yellow-500" : fgValue <= 75 ? "text-green-400" : "text-green-500";

  const cardClass = isDark ? "glass rounded-2xl p-6" : "bg-white rounded-2xl p-6 shadow-lg shadow-gray-200/50 border border-gray-100";
  const textPrimary = isDark ? "text-white" : "text-slate-900";
  const textSecondary = isDark ? "text-gray-400" : "text-gray-600";
  const textMuted = isDark ? "text-gray-500" : "text-gray-400";

  return (
    <div className={`min-h-screen pt-24 pb-16 ${isDark ? "bg-bg-dark" : "bg-gray-50"}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className={`text-3xl md:text-4xl font-bold font-[family-name:var(--font-space)] ${textPrimary}`}>Web3 Dashboard</h1>
            <p className={textSecondary}>Real-time crypto intelligence hub</p>
          </div>
          <button onClick={fetchAll} className="p-3 rounded-xl bg-brand/10 text-brand hover:bg-brand/20 transition-colors" title="Refresh">
            <RefreshCw className={`w-5 h-5 ${loading ? "animate-spin" : ""}`} />
          </button>
        </div>

        {/* Global Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { label: "Global Market Cap", value: globalData?.total_market_cap?.usd ? fmt(globalData.total_market_cap.usd) : "$2.65T", icon: <Globe className="w-5 h-5" /> },
            { label: "24h Volume", value: globalData?.total_volume?.usd ? fmt(globalData.total_volume.usd) : "$85B", icon: <Activity className="w-5 h-5" /> },
            { label: "BTC Dominance", value: `${(globalData?.market_cap_percentage?.btc ?? 52.1).toFixed(1)}%`, icon: <TrendingUp className="w-5 h-5" /> },
            { label: "ETH Dominance", value: `${(globalData?.market_cap_percentage?.eth ?? 16.8).toFixed(1)}%`, icon: <TrendingUp className="w-5 h-5" /> },
          ].map((s, i) => (
            <div key={i} className={cardClass}>
              <div className="flex items-center gap-2 mb-2">
                <span className="text-brand">{s.icon}</span>
                <span className={`text-xs ${textMuted}`}>{s.label}</span>
              </div>
              <p className={`text-xl font-bold font-[family-name:var(--font-space)] ${textPrimary}`}>{s.value}</p>
            </div>
          ))}
        </div>

        {/* Crypto Prices */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {coins.map((coin) => (
            <div key={coin.id} className={`${cardClass} card-hover`}>
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-brand/20 to-secondary/20 flex items-center justify-center text-sm font-bold text-brand uppercase">
                  {coin.symbol}
                </div>
                <div>
                  <p className={`font-semibold ${textPrimary}`}>{coin.name}</p>
                  <p className={`text-xs uppercase ${textMuted}`}>{coin.symbol}</p>
                </div>
              </div>
              <p className={`text-2xl font-bold font-[family-name:var(--font-space)] ${textPrimary}`}>
                ${coin.current_price?.toLocaleString() ?? "—"}
              </p>
              <div className="flex items-center gap-1 mt-1">
                {coin.price_change_percentage_24h >= 0 ? (
                  <TrendingUp className="w-4 h-4 text-green-400" />
                ) : (
                  <TrendingDown className="w-4 h-4 text-red-400" />
                )}
                <span className={coin.price_change_percentage_24h >= 0 ? "text-green-400" : "text-red-400"}>
                  {coin.price_change_percentage_24h?.toFixed(2) ?? "0.00"}%
                </span>
              </div>
              <p className={`text-xs mt-2 ${textMuted}`}>Vol: {fmt(coin.total_volume ?? 0)}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          {/* Fear & Greed */}
          <div className={cardClass}>
            <h3 className={`text-lg font-bold font-[family-name:var(--font-space)] mb-4 flex items-center gap-2 ${textPrimary}`}>
              <Activity className="w-5 h-5 text-brand" /> Fear & Greed Index
            </h3>
            <div className="text-center py-8">
              <div className={`text-6xl font-bold font-[family-name:var(--font-space)] ${fgColor}`}>{fgValue}</div>
              <p className={`text-lg font-semibold mt-2 ${fgColor}`}>{fgLabel}</p>
              <div className="w-full h-3 rounded-full bg-gradient-to-r from-red-500 via-yellow-500 to-green-500 mt-4 relative">
                <div className="absolute top-1/2 -translate-y-1/2 w-4 h-4 bg-white rounded-full shadow-lg border-2 border-gray-800" style={{ left: `${fgValue}%`, transform: "translate(-50%, -50%)" }} />
              </div>
              <div className="flex justify-between text-xs mt-1">
                <span className="text-red-500">Extreme Fear</span>
                <span className="text-green-500">Extreme Greed</span>
              </div>
            </div>
          </div>

          {/* Gas Tracker */}
          <div className={cardClass}>
            <h3 className={`text-lg font-bold font-[family-name:var(--font-space)] mb-4 flex items-center gap-2 ${textPrimary}`}>
              <Fuel className="w-5 h-5 text-brand" /> Gas Tracker
            </h3>
            {Object.entries(GAS_DATA).map(([chain, data]) => (
              <div key={chain} className={`mb-4 p-3 rounded-xl ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
                <p className={`text-sm font-semibold capitalize mb-2 ${textPrimary}`}>{chain}</p>
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div>
                    <p className="text-green-400 text-sm font-bold">{data.low}</p>
                    <p className={`text-xs ${textMuted}`}>Low</p>
                  </div>
                  <div>
                    <p className="text-yellow-400 text-sm font-bold">{data.avg}</p>
                    <p className={`text-xs ${textMuted}`}>Avg</p>
                  </div>
                  <div>
                    <p className="text-red-400 text-sm font-bold">{data.high}</p>
                    <p className={`text-xs ${textMuted}`}>High</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Whale Alerts */}
          <div className={cardClass}>
            <h3 className={`text-lg font-bold font-[family-name:var(--font-space)] mb-4 flex items-center gap-2 ${textPrimary}`}>
              <AlertTriangle className="w-5 h-5 text-brand" /> Whale Alerts
            </h3>
            <div className="space-y-3">
              {WHALE_ALERTS.map((w, i) => (
                <div key={i} className={`p-3 rounded-xl ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
                  <div className="flex items-center justify-between mb-1">
                    <span className={`text-sm font-bold ${textPrimary}`}>{w.amount}</span>
                    <span className={`text-xs ${textMuted}`}>{w.time}</span>
                  </div>
                  <p className={`text-xs ${textSecondary}`}>{w.from} → {w.to}</p>
                  <p className="text-xs text-brand font-semibold">{w.value}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Token Unlocks + IDO + Airdrops */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          <div className={cardClass}>
            <h3 className={`text-lg font-bold font-[family-name:var(--font-space)] mb-4 flex items-center gap-2 ${textPrimary}`}>
              <Calendar className="w-5 h-5 text-brand" /> Token Unlocks
            </h3>
            <div className="space-y-3">
              {TOKEN_UNLOCKS.map((t, i) => (
                <div key={i} className={`p-3 rounded-xl ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
                  <div className="flex justify-between items-center">
                    <span className={`font-semibold text-sm ${textPrimary}`}>{t.project} ({t.symbol})</span>
                    <span className="text-brand text-xs">{t.countdown}</span>
                  </div>
                  <div className="flex justify-between mt-1">
                    <span className={`text-xs ${textMuted}`}>Unlock: {t.unlockPct}%</span>
                    <span className={`text-xs ${textSecondary}`}>{t.value}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className={cardClass}>
            <h3 className={`text-lg font-bold font-[family-name:var(--font-space)] mb-4 flex items-center gap-2 ${textPrimary}`}>
              <Rocket className="w-5 h-5 text-brand" /> IDO / IEO Calendar
            </h3>
            <div className="space-y-3">
              {IDO_CALENDAR.map((t, i) => (
                <div key={i} className={`p-3 rounded-xl ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
                  <div className="flex justify-between items-center">
                    <span className={`font-semibold text-sm ${textPrimary}`}>{t.token}</span>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${t.status === "Open" ? "bg-green-500/20 text-green-400" : "bg-yellow-500/20 text-yellow-400"}`}>
                      {t.status}
                    </span>
                  </div>
                  <p className={`text-xs mt-1 ${textMuted}`}>{t.launchpad} • {t.date}</p>
                </div>
              ))}
            </div>
          </div>

          <div className={cardClass}>
            <h3 className={`text-lg font-bold font-[family-name:var(--font-space)] mb-4 flex items-center gap-2 ${textPrimary}`}>
              <Gift className="w-5 h-5 text-brand" /> Airdrop Calendar
            </h3>
            <div className="space-y-3">
              {AIRDROPS.map((a, i) => (
                <div key={i} className={`p-3 rounded-xl ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
                  <div className="flex justify-between items-center">
                    <span className={`font-semibold text-sm ${textPrimary}`}>{a.name}</span>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${a.status === "Active" ? "bg-green-500/20 text-green-400" : "bg-blue-500/20 text-blue-400"}`}>
                      {a.status}
                    </span>
                  </div>
                  <div className="flex justify-between mt-1">
                    <span className={`text-xs ${textMuted}`}>{a.reward}</span>
                    <span className={`text-xs ${textSecondary}`}>{a.difficulty}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* News Feed */}
        <div className={cardClass}>
          <h3 className={`text-lg font-bold font-[family-name:var(--font-space)] mb-4 flex items-center gap-2 ${textPrimary}`}>
            <Newspaper className="w-5 h-5 text-brand" /> Latest Crypto News
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {news.map((n, i) => (
              <div key={i} className={`p-4 rounded-xl card-hover ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
                <span className="text-xs text-brand font-medium">{n.category}</span>
                <h4 className={`font-semibold text-sm mt-1 mb-2 ${textPrimary}`}>{n.title}</h4>
                <p className={`text-xs mb-3 ${textMuted}`}>{n.description}</p>
                <div className="flex justify-between items-center">
                  <span className={`text-xs ${textMuted}`}>{n.source}</span>
                  <ExternalLink className={`w-3 h-3 ${textMuted}`} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Social Feeds */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-8">
          <div className={cardClass}>
            <h3 className={`text-lg font-bold font-[family-name:var(--font-space)] mb-4 ${textPrimary}`}>
              𝕏 Feed — @mahfuzxallum
            </h3>
            <div className="space-y-3">
              {["🚀 Just wrapped up a massive campaign for a top-10 exchange. 500K+ new users onboarded!", "🔥 Thread: The ultimate guide to Web3 marketing in 2025. 10 strategies that actually work.", "📊 Market analysis: Why this altcoin season could be the biggest yet. Data inside."].map((post, i) => (
                <div key={i} className={`p-3 rounded-xl ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
                  <p className={`text-sm ${textSecondary}`}>{post}</p>
                  <p className={`text-xs mt-2 ${textMuted}`}>{i + 1}h ago • ❤️ {(Math.random() * 500 + 100).toFixed(0)} • 🔄 {(Math.random() * 100 + 20).toFixed(0)}</p>
                </div>
              ))}
              <a href="https://x.com/mahfuzxallum" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 text-brand text-sm font-semibold hover:gap-3 transition-all">
                Follow on X <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>

          <div className={cardClass}>
            <h3 className={`text-lg font-bold font-[family-name:var(--font-space)] mb-4 ${textPrimary}`}>
              📱 Telegram — @mahfuzallum
            </h3>
            <div className="space-y-3">
              {["📌 PINNED: New partnership announcement coming this week. Stay tuned!", "🎯 Weekly alpha: Top 5 tokens to watch this week based on on-chain data.", "📢 AMA Session tomorrow at 3PM UTC with the team behind the hottest L2."].map((post, i) => (
                <div key={i} className={`p-3 rounded-xl ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
                  <p className={`text-sm ${textSecondary}`}>{post}</p>
                  <p className={`text-xs mt-2 ${textMuted}`}>{i + 2}h ago • 👁 {(Math.random() * 5000 + 1000).toFixed(0)} views</p>
                </div>
              ))}
              <a href="https://t.me/mahfuzallum" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 text-brand text-sm font-semibold hover:gap-3 transition-all">
                Join Telegram <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
