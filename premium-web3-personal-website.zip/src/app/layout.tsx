import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { Providers } from "./providers";

export const metadata: Metadata = {
  metadataBase: new URL("https://mahfuz.io"),
  title: {
    default: "Mahfuz | Web3 Growth Partner - KOL Marketing, Partnerships & Community",
    template: "%s | Mahfuz - Web3 Growth Partner",
  },
  description: "Helping Web3 Projects Scale Through Marketing, Partnerships & Community. KOL Marketing, Business Development, Exchange Partnerships, and Community Growth for blockchain startups.",
  keywords: ["Web3", "KOL Marketing", "Crypto Marketing", "Business Development", "Community Growth", "Exchange Partnerships", "Blockchain Marketing", "Mahfuz"],
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://mahfuz.io",
    siteName: "Mahfuz",
    title: "Mahfuz | Web3 Growth Partner",
    description: "Helping Web3 Projects Scale Through Marketing, Partnerships & Community.",
  },
  twitter: {
    card: "summary_large_image",
    creator: "@mahfuzxallum",
    title: "Mahfuz | Web3 Growth Partner",
    description: "Helping Web3 Projects Scale Through Marketing, Partnerships & Community.",
  },
  robots: { index: true, follow: true },
};

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "Person",
  name: "Mahfuz",
  url: "https://mahfuz.io",
  jobTitle: "Web3 Growth Partner",
  description: "KOL Marketing, Business Development, Exchange Partnerships, and Community Growth",
  sameAs: ["https://x.com/mahfuzxallum", "https://t.me/mahfuzallum"],
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="theme-cyber">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet" />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
      </head>
      <body className="bg-bg-dark text-white antialiased font-[family-name:var(--font-inter)]">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
