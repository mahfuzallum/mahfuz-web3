"use client";
import Link from "next/link";
import { Search, Clock, ArrowRight, Tag } from "lucide-react";
import { useState } from "react";
import SectionHeader from "@/components/SectionHeader";
import { useTheme } from "@/lib/theme-context";

const CATEGORIES = ["All", "Crypto", "AI", "Blockchain", "DeFi", "Trading", "Research"];

const BLOG_POSTS = [
  { slug: "web3-marketing-guide-2025", title: "The Ultimate Web3 Marketing Guide for 2025", excerpt: "Everything you need to know about marketing your blockchain project in 2025. From KOL campaigns to community building strategies.", category: "Crypto", readTime: "12 min", date: "Mar 10, 2025" },
  { slug: "defi-trends-2025", title: "Top 10 DeFi Trends Shaping the Industry", excerpt: "Explore the most impactful DeFi trends including restaking, intent-based protocols, and cross-chain interoperability.", category: "DeFi", readTime: "8 min", date: "Mar 8, 2025" },
  { slug: "ai-crypto-intersection", title: "Where AI Meets Crypto: Opportunities and Risks", excerpt: "An in-depth analysis of AI-powered blockchain projects and their potential to disrupt traditional finance.", category: "AI", readTime: "10 min", date: "Mar 5, 2025" },
  { slug: "exchange-listing-strategy", title: "How to Get Listed on Major Exchanges", excerpt: "A comprehensive guide to preparing for and securing listings on top-tier centralized exchanges.", category: "Trading", readTime: "15 min", date: "Mar 3, 2025" },
  { slug: "community-building-playbook", title: "The Web3 Community Building Playbook", excerpt: "Learn how to build, engage, and grow a thriving crypto community from scratch to 100K+ members.", category: "Crypto", readTime: "11 min", date: "Feb 28, 2025" },
  { slug: "blockchain-scalability-solutions", title: "Blockchain Scalability: L1 vs L2 Solutions", excerpt: "A technical comparison of different scalability approaches including rollups, sharding, and parallel execution.", category: "Blockchain", readTime: "9 min", date: "Feb 25, 2025" },
  { slug: "token-economics-design", title: "Designing Token Economics That Work", excerpt: "Key principles for creating sustainable tokenomics including emission schedules, utility, and governance.", category: "Research", readTime: "14 min", date: "Feb 22, 2025" },
  { slug: "web3-growth-metrics", title: "The Only Growth Metrics That Matter in Web3", excerpt: "Stop tracking vanity metrics. Here are the KPIs that actually indicate real growth for your project.", category: "Crypto", readTime: "7 min", date: "Feb 20, 2025" },
];

export default function BlogPage() {
  const { theme } = useTheme();
  const isDark = theme === "cyber";
  const [category, setCategory] = useState("All");
  const [search, setSearch] = useState("");

  const filtered = BLOG_POSTS.filter(p => {
    const matchCat = category === "All" || p.category === category;
    const matchSearch = p.title.toLowerCase().includes(search.toLowerCase()) || p.excerpt.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  const cardClass = isDark ? "glass rounded-2xl p-6" : "bg-white rounded-2xl p-6 shadow-lg border border-gray-100";
  const textPrimary = isDark ? "text-white" : "text-slate-900";
  const textSecondary = isDark ? "text-gray-400" : "text-gray-600";
  const textMuted = isDark ? "text-gray-500" : "text-gray-400";

  return (
    <div className={`min-h-screen pt-24 pb-16 ${isDark ? "bg-bg-dark" : "bg-gray-50"}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 pt-8">
          <span className="inline-block px-4 py-1.5 rounded-full text-xs font-semibold tracking-wider uppercase bg-brand/10 text-brand border border-brand/20 mb-4">Blog</span>
          <h1 className={`text-4xl md:text-5xl font-bold font-[family-name:var(--font-space)] mb-6 ${textPrimary}`}>
            Insights & <span className="gradient-text">Research</span>
          </h1>
          <p className={`text-lg max-w-2xl mx-auto ${textSecondary}`}>
            Deep dives into Web3 marketing, DeFi trends, blockchain technology, and growth strategies.
          </p>
        </div>

        {/* Search & Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-12">
          <div className="relative flex-1">
            <Search className={`absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 ${textMuted}`} />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search articles..."
              className={`w-full pl-12 pr-4 py-3 rounded-xl border ${isDark ? "bg-white/5 border-white/10 text-white placeholder:text-gray-500" : "bg-white border-gray-200 text-gray-900 placeholder:text-gray-400"} focus:outline-none focus:ring-2 focus:ring-brand/50`}
            />
          </div>
          <div className="flex flex-wrap gap-2">
            {CATEGORIES.map(c => (
              <button
                key={c}
                onClick={() => setCategory(c)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${category === c ? "bg-brand text-black" : isDark ? "bg-white/5 text-gray-400 hover:bg-white/10" : "bg-gray-100 text-gray-600 hover:bg-gray-200"}`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>

        {/* Blog Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map(post => (
            <article key={post.slug} className={`${cardClass} card-hover group`}>
              <div className="w-full h-48 rounded-xl bg-gradient-to-br from-brand/20 to-secondary/20 mb-4 flex items-center justify-center">
                <span className="text-4xl">📝</span>
              </div>
              <div className="flex items-center gap-3 mb-3">
                <span className="text-xs font-medium text-brand bg-brand/10 px-2 py-1 rounded-md">{post.category}</span>
                <span className={`text-xs flex items-center gap-1 ${textMuted}`}><Clock className="w-3 h-3" /> {post.readTime}</span>
              </div>
              <h3 className={`text-lg font-bold font-[family-name:var(--font-space)] mb-2 group-hover:text-brand transition-colors ${textPrimary}`}>
                {post.title}
              </h3>
              <p className={`text-sm mb-4 ${textSecondary}`}>{post.excerpt}</p>
              <div className="flex items-center justify-between">
                <span className={`text-xs ${textMuted}`}>{post.date}</span>
                <span className="text-brand text-sm font-semibold flex items-center gap-1 group-hover:gap-2 transition-all">
                  Read <ArrowRight className="w-3 h-3" />
                </span>
              </div>
            </article>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-16">
            <p className={textSecondary}>No articles found. Try a different search or category.</p>
          </div>
        )}
      </div>
    </div>
  );
}
