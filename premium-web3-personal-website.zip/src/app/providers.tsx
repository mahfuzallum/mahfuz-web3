"use client";
import type { ReactNode } from "react";
import { I18nProvider } from "@/lib/i18n-context";
import { ThemeProvider } from "@/lib/theme-context";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import CookieConsent from "@/components/CookieConsent";
import AiChat from "@/components/AiChat";

export function Providers({ children }: { children: ReactNode }) {
  return (
    <ThemeProvider>
      <I18nProvider>
        <Navbar />
        <main className="min-h-screen">{children}</main>
        <Footer />
        <AiChat />
        <CookieConsent />
      </I18nProvider>
    </ThemeProvider>
  );
}
