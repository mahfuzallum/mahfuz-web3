"use client";
import { useState } from "react";
import { Send, Mail, MessageCircle, ExternalLink, Calendar, CheckCircle, Globe } from "lucide-react";
import { SITE } from "@/lib/constants";
import { useTheme } from "@/lib/theme-context";

function XIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>;
}

export default function ContactPage() {
  const { theme } = useTheme();
  const isDark = theme === "cyber";
  const [form, setForm] = useState({ name: "", email: "", telegram: "", subject: "", message: "" });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const cardClass = isDark ? "glass rounded-2xl p-8" : "bg-white rounded-2xl p-8 shadow-lg border border-gray-100";
  const textPrimary = isDark ? "text-white" : "text-slate-900";
  const textSecondary = isDark ? "text-gray-400" : "text-gray-600";
  const inputClass = isDark
    ? "w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder:text-gray-500 focus:outline-none focus:ring-2 focus:ring-brand/50"
    : "w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-brand/50";

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await fetch("/api/contact", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
      setSubmitted(true);
    } catch { /* noop */ }
    setLoading(false);
  };

  return (
    <div className={`min-h-screen pt-24 pb-16 ${isDark ? "bg-bg-dark" : "bg-gray-50"}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 pt-8">
          <span className="inline-block px-4 py-1.5 rounded-full text-xs font-semibold tracking-wider uppercase bg-brand/10 text-brand border border-brand/20 mb-4">Contact</span>
          <h1 className={`text-4xl md:text-5xl font-bold font-[family-name:var(--font-space)] mb-6 ${textPrimary}`}>
            Let&apos;s <span className="gradient-text">Work Together</span>
          </h1>
          <p className={`text-lg max-w-2xl mx-auto ${textSecondary}`}>
            Ready to scale your Web3 project? Get in touch and let&apos;s discuss how we can drive growth together.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Contact Info */}
          <div className="space-y-6">
            {[
              { icon: <Send className="w-5 h-5" />, label: "Telegram", value: "@mahfuzallum", href: SITE.telegram },
              { icon: <XIcon className="w-5 h-5" />, label: "Twitter/X", value: "@mahfuzxallum", href: SITE.twitter },
              { icon: <Mail className="w-5 h-5" />, label: "Email", value: SITE.email, href: `mailto:${SITE.email}` },
              { icon: <Calendar className="w-5 h-5" />, label: "Book a Call", value: "Schedule via Calendly", href: SITE.calendly },
            ].map((c, i) => (
              <a key={i} href={c.href} target="_blank" rel="noopener noreferrer" className={`${cardClass} flex items-center gap-4 card-hover block`}>
                <div className="w-12 h-12 rounded-xl bg-brand/10 flex items-center justify-center text-brand">{c.icon}</div>
                <div>
                  <p className={`text-sm ${textSecondary}`}>{c.label}</p>
                  <p className={`font-semibold ${textPrimary}`}>{c.value}</p>
                </div>
                <ExternalLink className={`w-4 h-4 ml-auto ${isDark ? "text-gray-600" : "text-gray-300"}`} />
              </a>
            ))}
          </div>

          {/* Contact Form */}
          <div className={`${cardClass} lg:col-span-2`}>
            {submitted ? (
              <div className="text-center py-12">
                <CheckCircle className="w-16 h-16 text-brand mx-auto mb-4" />
                <h3 className={`text-2xl font-bold font-[family-name:var(--font-space)] mb-2 ${textPrimary}`}>Message Sent!</h3>
                <p className={textSecondary}>Thank you for reaching out. I&apos;ll get back to you within 24 hours.</p>
              </div>
            ) : (
              <form onSubmit={submit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className={`block text-sm font-medium mb-2 ${textPrimary}`}>Name *</label>
                    <input type="text" required value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Your name" className={inputClass} />
                  </div>
                  <div>
                    <label className={`block text-sm font-medium mb-2 ${textPrimary}`}>Email *</label>
                    <input type="email" required value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} placeholder="your@email.com" className={inputClass} />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className={`block text-sm font-medium mb-2 ${textPrimary}`}>Telegram</label>
                    <input type="text" value={form.telegram} onChange={e => setForm({ ...form, telegram: e.target.value })} placeholder="@username" className={inputClass} />
                  </div>
                  <div>
                    <label className={`block text-sm font-medium mb-2 ${textPrimary}`}>Subject *</label>
                    <select required value={form.subject} onChange={e => setForm({ ...form, subject: e.target.value })} className={inputClass}>
                      <option value="">Select a subject</option>
                      <option value="KOL Marketing">KOL Marketing</option>
                      <option value="Business Development">Business Development</option>
                      <option value="Exchange Partnership">Exchange Partnership</option>
                      <option value="Community Growth">Community Growth</option>
                      <option value="Launch Campaign">Launch Campaign</option>
                      <option value="Growth Consulting">Growth Consulting</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className={`block text-sm font-medium mb-2 ${textPrimary}`}>Message *</label>
                  <textarea required rows={5} value={form.message} onChange={e => setForm({ ...form, message: e.target.value })} placeholder="Tell me about your project..." className={inputClass} />
                </div>
                <button type="submit" disabled={loading} className="w-full py-4 bg-gradient-to-r from-brand to-secondary text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-brand/25 transition-all disabled:opacity-50 flex items-center justify-center gap-2">
                  {loading ? "Sending..." : "Send Message"} <Send className="w-4 h-4" />
                </button>
              </form>
            )}
          </div>
        </div>

        {/* Calendly Embed */}
        <div className="mt-16">
          <div className="text-center mb-8">
            <h2 className={`text-2xl font-bold font-[family-name:var(--font-space)] ${textPrimary}`}>Schedule a Call</h2>
            <p className={textSecondary}>Pick a time that works for you</p>
          </div>
          <div className={`${cardClass} text-center py-16`}>
            <Calendar className="w-16 h-16 text-brand mx-auto mb-4" />
            <h3 className={`text-xl font-bold mb-2 ${textPrimary}`}>Calendly Integration Ready</h3>
            <p className={`mb-6 ${textSecondary}`}>Connect your Calendly account to enable direct booking.</p>
            <a href={SITE.calendly} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-brand to-secondary text-white font-semibold rounded-xl hover:shadow-lg transition-all">
              Open Calendly <ExternalLink className="w-4 h-4" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
