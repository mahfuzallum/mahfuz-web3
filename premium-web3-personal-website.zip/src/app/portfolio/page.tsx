"use client";
import Link from "next/link";
import { Star, ChevronRight, ExternalLink } from "lucide-react";
import SectionHeader from "@/components/SectionHeader";
import AnimatedCounter from "@/components/AnimatedCounter";
import { PORTFOLIO, STATS, TESTIMONIALS } from "@/lib/constants";
import { useTheme } from "@/lib/theme-context";

export default function PortfolioPage() {
  const { theme } = useTheme();
  const isDark = theme === "cyber";
  const cardClass = isDark ? "glass rounded-2xl p-6" : "bg-white rounded-2xl p-6 shadow-lg border border-gray-100";
  const textPrimary = isDark ? "text-white" : "text-slate-900";
  const textSecondary = isDark ? "text-gray-400" : "text-gray-600";
  const textMuted = isDark ? "text-gray-500" : "text-gray-400";

  return (
    <div className={`min-h-screen pt-24 pb-16 ${isDark ? "bg-bg-dark" : "bg-gray-50"}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20 pt-8">
          <span className="inline-block px-4 py-1.5 rounded-full text-xs font-semibold tracking-wider uppercase bg-brand/10 text-brand border border-brand/20 mb-4">Portfolio</span>
          <h1 className={`text-4xl md:text-5xl lg:text-6xl font-bold font-[family-name:var(--font-space)] mb-6 ${textPrimary}`}>
            Projects & <span className="gradient-text">Case Studies</span>
          </h1>
          <p className={`text-lg max-w-3xl mx-auto ${textSecondary}`}>
            Real results from real campaigns. Every project is backed by data, measurable outcomes, and client testimonials.
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6 mb-20">
          {STATS.map((s) => (
            <div key={s.label} className="text-center">
              <div className="text-3xl font-bold font-[family-name:var(--font-space)] gradient-text mb-1">
                <AnimatedCounter value={s.value} suffix={s.suffix} />
              </div>
              <div className={`text-xs ${textMuted}`}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* Portfolio Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-20">
          {PORTFOLIO.map((p, i) => (
            <div key={i} className={`${cardClass} card-hover`}>
              <div className="flex items-center gap-4 mb-6">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-brand to-secondary flex items-center justify-center text-white text-2xl font-bold">
                  {p.name[0]}
                </div>
                <div>
                  <h3 className={`text-xl font-bold font-[family-name:var(--font-space)] ${textPrimary}`}>{p.name}</h3>
                  <span className="text-brand text-sm font-medium">{p.category}</span>
                </div>
              </div>
              <div className={`p-4 rounded-xl mb-4 ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
                <p className={`text-sm font-medium ${textSecondary}`}>Campaign Goal</p>
                <p className={`text-sm ${textPrimary}`}>{p.goal}</p>
              </div>
              <div className="p-4 rounded-xl bg-brand/10 mb-4">
                <p className="text-sm font-medium text-brand">Result</p>
                <p className="text-sm font-bold text-brand">{p.result}</p>
              </div>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className={`p-3 rounded-xl text-center ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
                  <p className={`text-xs ${textMuted}`}>Total Reach</p>
                  <p className={`text-lg font-bold ${textPrimary}`}>{p.reach}</p>
                </div>
                <div className={`p-3 rounded-xl text-center ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
                  <p className={`text-xs ${textMuted}`}>Engagement</p>
                  <p className={`text-lg font-bold ${textPrimary}`}>{p.engagement}</p>
                </div>
              </div>
              <blockquote className={`text-sm italic ${textSecondary} border-l-2 border-brand pl-4`}>
                &ldquo;{p.feedback}&rdquo;
              </blockquote>
            </div>
          ))}
        </div>

        {/* Testimonials */}
        <SectionHeader badge="Testimonials" title="Client Feedback" subtitle="Hear directly from the founders and executives who trusted me with their growth." />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-16">
          {TESTIMONIALS.map((t, i) => (
            <div key={i} className={`${cardClass} card-hover`}>
              <div className="flex gap-1 mb-3">
                {Array.from({ length: t.rating }).map((_, j) => (
                  <Star key={j} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                ))}
              </div>
              <p className={`mb-4 ${textSecondary}`}>&ldquo;{t.text}&rdquo;</p>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-brand to-secondary flex items-center justify-center text-white text-sm font-bold">
                  {t.name.split(" ").map(n => n[0]).join("")}
                </div>
                <div>
                  <p className={`text-sm font-semibold ${textPrimary}`}>{t.name}</p>
                  <p className={`text-xs ${textMuted}`}>{t.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center">
          <Link href="/contact" className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-brand to-secondary text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-brand/25 transition-all">
            Start Your Project <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </div>
  );
}
