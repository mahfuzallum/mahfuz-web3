import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { clientInquiries } from "@/db/schema";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { projectName, contactName, contactEmail } = body;
    if (!projectName || !contactName || !contactEmail) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }
    await db.insert(clientInquiries).values(body);
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
