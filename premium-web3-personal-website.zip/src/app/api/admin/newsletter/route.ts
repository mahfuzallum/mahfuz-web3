import { NextResponse } from "next/server";
import { db } from "@/db";
import { newsletter } from "@/db/schema";
import { desc } from "drizzle-orm";

export async function GET() {
  try {
    const rows = await db.select().from(newsletter).orderBy(desc(newsletter.createdAt)).limit(50);
    return NextResponse.json(rows);
  } catch {
    return NextResponse.json([]);
  }
}
