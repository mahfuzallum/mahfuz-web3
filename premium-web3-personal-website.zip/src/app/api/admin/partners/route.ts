import { NextResponse } from "next/server";
import { db } from "@/db";
import { partnerInquiries } from "@/db/schema";
import { desc } from "drizzle-orm";

export async function GET() {
  try {
    const rows = await db.select().from(partnerInquiries).orderBy(desc(partnerInquiries.createdAt)).limit(50);
    return NextResponse.json(rows);
  } catch {
    return NextResponse.json([]);
  }
}
