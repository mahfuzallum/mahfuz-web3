import { NextResponse } from "next/server";
import { db } from "@/db";
import { contacts, newsletter, clientInquiries, partnerInquiries } from "@/db/schema";
import { sql } from "drizzle-orm";

export async function GET() {
  try {
    const [contactCount] = await db.select({ count: sql<number>`count(*)` }).from(contacts);
    const [subCount] = await db.select({ count: sql<number>`count(*)` }).from(newsletter);
    const [inquiryCount] = await db.select({ count: sql<number>`count(*)` }).from(clientInquiries);
    const [partnerCount] = await db.select({ count: sql<number>`count(*)` }).from(partnerInquiries);
    return NextResponse.json({
      contacts: Number(contactCount.count),
      subscribers: Number(subCount.count),
      inquiries: Number(inquiryCount.count),
      partners: Number(partnerCount.count),
    });
  } catch {
    return NextResponse.json({ contacts: 0, subscribers: 0, inquiries: 0, partners: 0 });
  }
}
