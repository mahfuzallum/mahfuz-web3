import { NextResponse } from "next/server";

export const revalidate = 600;

const FALLBACK_NEWS = [
  { title: "Bitcoin Surges Past Key Resistance Level", description: "BTC breaks through major resistance as institutional buying continues.", source: "CryptoNews", publishedAt: new Date().toISOString(), url: "#", category: "Bitcoin" },
  { title: "Ethereum Layer 2 TVL Reaches New All-Time High", description: "Combined TVL across L2s exceeds $40B as adoption accelerates.", source: "The Block", publishedAt: new Date().toISOString(), url: "#", category: "Ethereum" },
  { title: "Solana DeFi Ecosystem Expands with New Protocols", description: "Multiple new DeFi protocols launch on Solana, driving ecosystem growth.", source: "DeFi Pulse", publishedAt: new Date().toISOString(), url: "#", category: "Solana" },
  { title: "Major Exchange Announces New Trading Features", description: "Top exchange rolls out advanced trading tools for institutional clients.", source: "CoinDesk", publishedAt: new Date().toISOString(), url: "#", category: "Exchange" },
  { title: "Web3 Gaming Sector Sees 300% Growth in Active Users", description: "Blockchain gaming platforms report unprecedented user growth in Q1.", source: "GameFi News", publishedAt: new Date().toISOString(), url: "#", category: "Gaming" },
  { title: "DeFi Protocol Launches Cross-Chain Bridge", description: "New bridge enables seamless asset transfers across 10+ blockchains.", source: "DeFi World", publishedAt: new Date().toISOString(), url: "#", category: "DeFi" },
];

export async function GET() {
  return NextResponse.json(FALLBACK_NEWS);
}
