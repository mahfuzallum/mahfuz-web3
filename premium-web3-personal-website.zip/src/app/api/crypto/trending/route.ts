import { NextResponse } from "next/server";

export const revalidate = 300;

export async function GET() {
  try {
    const res = await fetch("https://api.coingecko.com/api/v3/search/trending", { next: { revalidate: 300 } });
    if (!res.ok) throw new Error("CoinGecko trending API error");
    const data = await res.json();
    return NextResponse.json(data);
  } catch {
    return NextResponse.json({
      coins: [
        { item: { id: "pepe", name: "Pepe", symbol: "PEPE", market_cap_rank: 25, thumb: "", data: { price_change_percentage_24h: { usd: 5.2 } } } },
        { item: { id: "dogecoin", name: "Dogecoin", symbol: "DOGE", market_cap_rank: 8, thumb: "", data: { price_change_percentage_24h: { usd: 3.1 } } } },
      ],
    });
  }
}
