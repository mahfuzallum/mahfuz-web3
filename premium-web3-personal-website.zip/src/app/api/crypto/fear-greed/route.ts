import { NextResponse } from "next/server";

export const revalidate = 300;

export async function GET() {
  try {
    const res = await fetch("https://api.alternative.me/fng/?limit=30", { next: { revalidate: 300 } });
    if (!res.ok) throw new Error("Fear & Greed API error");
    const data = await res.json();
    return NextResponse.json(data);
  } catch {
    return NextResponse.json({
      data: [
        { value: "72", value_classification: "Greed", timestamp: String(Math.floor(Date.now() / 1000)) },
      ],
    });
  }
}
