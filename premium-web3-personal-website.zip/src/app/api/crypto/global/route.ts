import { NextResponse } from "next/server";

export const revalidate = 120;

export async function GET() {
  try {
    const res = await fetch("https://api.coingecko.com/api/v3/global", { next: { revalidate: 120 } });
    if (!res.ok) throw new Error("CoinGecko global API error");
    const data = await res.json();
    return NextResponse.json(data);
  } catch {
    return NextResponse.json({
      data: {
        total_market_cap: { usd: 2650000000000 },
        total_volume: { usd: 85000000000 },
        market_cap_percentage: { btc: 52.1, eth: 16.8 },
        active_cryptocurrencies: 12500,
        markets: 820,
      },
    });
  }
}
