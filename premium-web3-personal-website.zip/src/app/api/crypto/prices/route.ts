import { NextResponse } from "next/server";

export const revalidate = 60;

export async function GET() {
  try {
    const res = await fetch(
      "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=bitcoin,ethereum,binancecoin,solana&order=market_cap_desc&sparkline=false&price_change_percentage=24h",
      { next: { revalidate: 60 } }
    );
    if (!res.ok) throw new Error("CoinGecko API error");
    const data = await res.json();
    return NextResponse.json(data);
  } catch {
    // Fallback data
    return NextResponse.json([
      { id: "bitcoin", symbol: "btc", name: "Bitcoin", current_price: 67500, market_cap: 1320000000000, price_change_percentage_24h: 2.5, total_volume: 28000000000, image: "" },
      { id: "ethereum", symbol: "eth", name: "Ethereum", current_price: 3450, market_cap: 415000000000, price_change_percentage_24h: 1.8, total_volume: 15000000000, image: "" },
      { id: "binancecoin", symbol: "bnb", name: "BNB", current_price: 580, market_cap: 89000000000, price_change_percentage_24h: -0.5, total_volume: 1200000000, image: "" },
      { id: "solana", symbol: "sol", name: "Solana", current_price: 175, market_cap: 76000000000, price_change_percentage_24h: 3.2, total_volume: 3500000000, image: "" },
    ]);
  }
}
