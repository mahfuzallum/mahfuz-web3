import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { partnerInquiries } from "@/db/schema";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { companyName, contactName, email, partnershipType, message } = body;
    if (!companyName || !contactName || !email || !partnershipType || !message) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }
    await db.insert(partnerInquiries).values({ companyName, contactName, email, partnershipType, message });
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
