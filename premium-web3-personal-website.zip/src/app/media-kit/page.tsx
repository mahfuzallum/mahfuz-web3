"use client";
import { Download, Users, Globe, TrendingUp, BarChart, FileText, Image, ChevronRight } from "lucide-react";
import SectionHeader from "@/components/SectionHeader";
import AnimatedCounter from "@/components/AnimatedCounter";
import { useTheme } from "@/lib/theme-context";

const DEMOGRAPHICS = [
  { country: "United States", pct: 22 },
  { country: "India", pct: 15 },
  { country: "Turkey", pct: 10 },
  { country: "Nigeria", pct: 8 },
  { country: "Indonesia", pct: 7 },
  { country: "United Kingdom", pct: 6 },
];

const PAST_PARTNERS = ["Binance", "OKX", "Bybit", "Gate.io", "KuCoin", "MEXC", "Bitget", "HTX", "CoinW", "BingX"];

export default function MediaKitPage() {
  const { theme } = useTheme();
  const isDark = theme === "cyber";
  const cardClass = isDark ? "glass rounded-2xl p-6" : "bg-white rounded-2xl p-6 shadow-lg border border-gray-100";
  const textPrimary = isDark ? "text-white" : "text-slate-900";
  const textSecondary = isDark ? "text-gray-400" : "text-gray-600";
  const textMuted = isDark ? "text-gray-500" : "text-gray-400";

  return (
    <div className={`min-h-screen pt-24 pb-16 ${isDark ? "bg-bg-dark" : "bg-gray-50"}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 pt-8">
          <span className="inline-block px-4 py-1.5 rounded-full text-xs font-semibold tracking-wider uppercase bg-brand/10 text-brand border border-brand/20 mb-4">Media Kit</span>
          <h1 className={`text-4xl md:text-5xl font-bold font-[family-name:var(--font-space)] mb-6 ${textPrimary}`}>
            Media Kit & <span className="gradient-text">Brand Assets</span>
          </h1>
          <p className={`text-lg max-w-2xl mx-auto ${textSecondary}`}>
            Everything you need to know about collaborating with Mahfuz. Download brand assets and view audience demographics.
          </p>
        </div>

        {/* Audience Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
          {[
            { label: "Total Followers", value: 500, suffix: "K+", icon: <Users className="w-5 h-5" /> },
            { label: "Monthly Reach", value: 50, suffix: "M+", icon: <Globe className="w-5 h-5" /> },
            { label: "Engagement Rate", value: 8, suffix: "%+", icon: <TrendingUp className="w-5 h-5" /> },
            { label: "Countries", value: 50, suffix: "+", icon: <BarChart className="w-5 h-5" /> },
          ].map((s, i) => (
            <div key={i} className={`${cardClass} text-center`}>
              <div className="w-12 h-12 rounded-xl bg-brand/10 flex items-center justify-center text-brand mx-auto mb-3">{s.icon}</div>
              <div className="text-2xl font-bold font-[family-name:var(--font-space)] gradient-text">
                <AnimatedCounter value={s.value} suffix={s.suffix} />
              </div>
              <p className={`text-sm mt-1 ${textMuted}`}>{s.label}</p>
            </div>
          ))}
        </div>

        {/* Demographics */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
          <div className={cardClass}>
            <h3 className={`text-lg font-bold font-[family-name:var(--font-space)] mb-6 ${textPrimary}`}>Top Countries</h3>
            <div className="space-y-4">
              {DEMOGRAPHICS.map((d) => (
                <div key={d.country}>
                  <div className="flex justify-between mb-1">
                    <span className={`text-sm ${textSecondary}`}>{d.country}</span>
                    <span className="text-sm text-brand font-semibold">{d.pct}%</span>
                  </div>
                  <div className={`w-full h-2 rounded-full ${isDark ? "bg-white/10" : "bg-gray-100"}`}>
                    <div className="h-full rounded-full bg-gradient-to-r from-brand to-secondary" style={{ width: `${d.pct}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className={cardClass}>
            <h3 className={`text-lg font-bold font-[family-name:var(--font-space)] mb-6 ${textPrimary}`}>Past Partners</h3>
            <div className="flex flex-wrap gap-3">
              {PAST_PARTNERS.map((p) => (
                <span key={p} className={`px-4 py-2 rounded-xl text-sm font-medium ${isDark ? "bg-white/5 text-gray-300 border border-white/10" : "bg-gray-50 text-gray-700 border border-gray-200"}`}>
                  {p}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Downloads */}
        <SectionHeader badge="Downloads" title="Downloadable Assets" subtitle="Download brand assets, media kit, rate card, and portfolio." />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { title: "Full Media Kit", desc: "Complete brand guide and media kit", icon: <FileText className="w-6 h-6" />, format: "PDF" },
            { title: "One Pager", desc: "Quick overview of services and stats", icon: <FileText className="w-6 h-6" />, format: "PDF" },
            { title: "Rate Card", desc: "Pricing and package details", icon: <FileText className="w-6 h-6" />, format: "PDF" },
            { title: "Portfolio", desc: "Case studies and project results", icon: <Image className="w-6 h-6" />, format: "PDF" },
          ].map((d, i) => (
            <div key={i} className={`${cardClass} card-hover text-center`}>
              <div className="w-14 h-14 rounded-2xl bg-brand/10 flex items-center justify-center text-brand mx-auto mb-4">{d.icon}</div>
              <h4 className={`font-bold mb-1 ${textPrimary}`}>{d.title}</h4>
              <p className={`text-sm mb-4 ${textSecondary}`}>{d.desc}</p>
              <button className="inline-flex items-center gap-2 px-4 py-2 bg-brand/10 text-brand text-sm font-semibold rounded-lg hover:bg-brand/20 transition-colors">
                <Download className="w-4 h-4" /> {d.format}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
