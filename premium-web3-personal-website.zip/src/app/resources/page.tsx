"use client";
import { BookOpen, Download, ExternalLink, FileText, Lightbulb, Wrench, GraduationCap } from "lucide-react";
import SectionHeader from "@/components/SectionHeader";
import { useTheme } from "@/lib/theme-context";

const GUIDES = [
  { title: "Web3 Marketing Masterclass", desc: "Complete guide to marketing your blockchain project from pre-launch to post-TGE.", type: "Guide", difficulty: "Intermediate" },
  { title: "Community Building 101", desc: "Step-by-step guide to building a thriving crypto community from scratch.", type: "Guide", difficulty: "Beginner" },
  { title: "Exchange Listing Handbook", desc: "Everything you need to know about getting listed on centralized exchanges.", type: "Handbook", difficulty: "Advanced" },
  { title: "Token Launch Checklist", desc: "Pre-launch, launch day, and post-launch checklist for a successful token launch.", type: "Checklist", difficulty: "Beginner" },
];

const TOOLS = [
  { title: "On-Chain Analytics", desc: "Track wallet activity, token flows, and smart contract interactions.", icon: "📊" },
  { title: "Social Sentiment Tracker", desc: "Monitor social media sentiment across Twitter, Telegram, and Discord.", icon: "📈" },
  { title: "Tokenomics Calculator", desc: "Model different tokenomics scenarios and vesting schedules.", icon: "🧮" },
  { title: "Airdrop Tracker", desc: "Track the latest airdrops and eligibility requirements.", icon: "🎯" },
];

const RESEARCH = [
  { title: "Layer 1 Comparison Report Q1 2025", category: "Layer 1", date: "Mar 2025" },
  { title: "DeFi Yield Strategies Analysis", category: "DeFi", date: "Feb 2025" },
  { title: "AI x Crypto Market Map", category: "AI", date: "Feb 2025" },
  { title: "Gaming Token Economics Study", category: "Gaming", date: "Jan 2025" },
  { title: "RWA Tokenization Overview", category: "RWA", date: "Jan 2025" },
  { title: "Infrastructure Investment Thesis", category: "Infrastructure", date: "Dec 2024" },
];

export default function ResourcesPage() {
  const { theme } = useTheme();
  const isDark = theme === "cyber";
  const cardClass = isDark ? "glass rounded-2xl p-6" : "bg-white rounded-2xl p-6 shadow-lg border border-gray-100";
  const textPrimary = isDark ? "text-white" : "text-slate-900";
  const textSecondary = isDark ? "text-gray-400" : "text-gray-600";
  const textMuted = isDark ? "text-gray-500" : "text-gray-400";

  return (
    <div className={`min-h-screen pt-24 pb-16 ${isDark ? "bg-bg-dark" : "bg-gray-50"}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 pt-8">
          <span className="inline-block px-4 py-1.5 rounded-full text-xs font-semibold tracking-wider uppercase bg-brand/10 text-brand border border-brand/20 mb-4">Resources</span>
          <h1 className={`text-4xl md:text-5xl font-bold font-[family-name:var(--font-space)] mb-6 ${textPrimary}`}>
            Learn & <span className="gradient-text">Grow</span>
          </h1>
          <p className={`text-lg max-w-2xl mx-auto ${textSecondary}`}>
            Free guides, tools, research reports, and educational content to help you succeed in Web3.
          </p>
        </div>

        {/* Guides */}
        <SectionHeader badge="Guides" title="Free Learning Resources" subtitle="Comprehensive guides and handbooks for Web3 marketing and growth." />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-20">
          {GUIDES.map((g, i) => (
            <div key={i} className={`${cardClass} card-hover flex gap-4`}>
              <div className="w-12 h-12 rounded-xl bg-brand/10 flex items-center justify-center text-brand shrink-0">
                <BookOpen className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className={`font-bold ${textPrimary}`}>{g.title}</h3>
                </div>
                <p className={`text-sm mb-3 ${textSecondary}`}>{g.desc}</p>
                <div className="flex items-center gap-3">
                  <span className="text-xs font-medium text-brand bg-brand/10 px-2 py-1 rounded-md">{g.type}</span>
                  <span className={`text-xs ${textMuted}`}>{g.difficulty}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Tools */}
        <SectionHeader badge="Tools" title="Free Crypto Tools" subtitle="Useful tools for tracking, analyzing, and managing your Web3 project." />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-20">
          {TOOLS.map((t, i) => (
            <div key={i} className={`${cardClass} card-hover text-center`}>
              <div className="text-4xl mb-4">{t.icon}</div>
              <h3 className={`font-bold mb-2 ${textPrimary}`}>{t.title}</h3>
              <p className={`text-sm ${textSecondary}`}>{t.desc}</p>
            </div>
          ))}
        </div>

        {/* Research */}
        <SectionHeader badge="Research" title="Weekly Research Reports" subtitle="Premium research reports covering Layer 1, DeFi, AI, Gaming, RWA, and Infrastructure." />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {RESEARCH.map((r, i) => (
            <div key={i} className={`${cardClass} card-hover`}>
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-lg bg-brand/10 flex items-center justify-center text-brand shrink-0">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h3 className={`font-bold text-sm mb-1 ${textPrimary}`}>{r.title}</h3>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-brand bg-brand/10 px-2 py-0.5 rounded">{r.category}</span>
                    <span className={`text-xs ${textMuted}`}>{r.date}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
