"use client";
import Link from "next/link";
import { Home, ArrowLeft } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen bg-bg-dark flex items-center justify-center relative overflow-hidden">
      <div className="absolute inset-0 hero-gradient" />
      <div className="absolute inset-0 animate-grid" />
      <div className="absolute top-1/3 left-1/4 w-64 h-64 bg-brand/10 rounded-full blur-[100px] animate-float" />
      <div className="absolute bottom-1/3 right-1/4 w-96 h-96 bg-secondary/10 rounded-full blur-[120px] animate-float" style={{ animationDelay: "3s" }} />

      <div className="relative z-10 text-center px-4">
        <div className="text-8xl md:text-[12rem] font-bold font-[family-name:var(--font-space)] gradient-text leading-none mb-4">
          404
        </div>
        <h1 className="text-2xl md:text-4xl font-bold font-[family-name:var(--font-space)] text-white mb-4">
          Page Not Found
        </h1>
        <p className="text-gray-400 text-lg max-w-md mx-auto mb-8">
          Looks like this page got lost in the blockchain. Let&apos;s get you back on track.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link
            href="/"
            className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-brand to-secondary text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-brand/25 transition-all"
          >
            <Home className="w-4 h-4" /> Go Home
          </Link>
          <Link
            href="/contact"
            className="inline-flex items-center gap-2 px-6 py-3 bg-white/5 border border-white/10 text-white font-semibold rounded-xl hover:bg-white/10 transition-all"
          >
            <ArrowLeft className="w-4 h-4" /> Contact Support
          </Link>
        </div>
      </div>
    </div>
  );
}
