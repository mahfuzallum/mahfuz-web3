"use client";
import Link from "next/link";
import { Megaphone, Handshake, Building, Users, Send, ExternalLink, Star, Mic, Rocket, Coins, TrendingUp, PenTool, Zap, ChevronRight, CheckCircle } from "lucide-react";
import SectionHeader from "@/components/SectionHeader";
import { SERVICES } from "@/lib/constants";
import { useTheme } from "@/lib/theme-context";

const ICON_MAP: Record<string, React.ReactNode> = {
  megaphone: <Megaphone className="w-7 h-7" />,
  handshake: <Handshake className="w-7 h-7" />,
  building: <Building className="w-7 h-7" />,
  users: <Users className="w-7 h-7" />,
  send: <Send className="w-7 h-7" />,
  twitter: <ExternalLink className="w-7 h-7" />,
  star: <Star className="w-7 h-7" />,
  mic: <Mic className="w-7 h-7" />,
  rocket: <Rocket className="w-7 h-7" />,
  coins: <Coins className="w-7 h-7" />,
  trendingUp: <TrendingUp className="w-7 h-7" />,
  penTool: <PenTool className="w-7 h-7" />,
};

const PROCESS = [
  { step: "01", title: "Discovery", desc: "Understanding your project, goals, target audience, and competitive landscape." },
  { step: "02", title: "Strategy", desc: "Crafting a tailored growth strategy with clear KPIs and timelines." },
  { step: "03", title: "Execution", desc: "Implementing campaigns across all channels with dedicated team support." },
  { step: "04", title: "Optimization", desc: "Continuous monitoring, A/B testing, and optimization for maximum ROI." },
];

export default function ServicesPage() {
  const { theme } = useTheme();
  const isDark = theme === "cyber";
  const cardClass = isDark ? "gradient-border rounded-2xl p-8" : "gradient-border-light rounded-2xl p-8";
  const textPrimary = isDark ? "text-white" : "text-slate-900";
  const textSecondary = isDark ? "text-gray-400" : "text-gray-600";

  return (
    <div className={`min-h-screen pt-24 pb-16 ${isDark ? "bg-bg-dark" : "bg-gray-50"}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20 pt-8">
          <span className="inline-block px-4 py-1.5 rounded-full text-xs font-semibold tracking-wider uppercase bg-brand/10 text-brand border border-brand/20 mb-4">Services</span>
          <h1 className={`text-4xl md:text-5xl lg:text-6xl font-bold font-[family-name:var(--font-space)] mb-6 ${textPrimary}`}>
            Web3 <span className="gradient-text">Growth Solutions</span>
          </h1>
          <p className={`text-lg max-w-3xl mx-auto ${textSecondary}`}>
            Comprehensive marketing and growth services designed specifically for blockchain projects, exchanges, and Web3 communities.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-24">
          {SERVICES.map((svc) => (
            <div key={svc.title} className={`${cardClass} group card-hover`}>
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-brand/20 to-secondary/20 flex items-center justify-center text-brand mb-6 group-hover:scale-110 transition-transform">
                {ICON_MAP[svc.icon] || <Zap className="w-7 h-7" />}
              </div>
              <h3 className={`text-xl font-bold font-[family-name:var(--font-space)] mb-3 ${textPrimary}`}>{svc.title}</h3>
              <p className={`text-sm mb-4 leading-relaxed ${textSecondary}`}>{svc.desc}</p>
              <div className="flex items-center justify-between">
                <span className="text-brand font-bold text-sm">{svc.stats}</span>
                <ChevronRight className="w-4 h-4 text-brand opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </div>
          ))}
        </div>

        {/* Process */}
        <SectionHeader badge="Process" title="How We Work" subtitle="A proven 4-step process to deliver measurable results for your Web3 project." />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-24">
          {PROCESS.map((p) => (
            <div key={p.step} className={`${isDark ? "glass" : "bg-white shadow-lg border border-gray-100"} rounded-2xl p-6 text-center card-hover`}>
              <div className="text-4xl font-bold font-[family-name:var(--font-space)] gradient-text mb-4">{p.step}</div>
              <h4 className={`text-lg font-bold mb-2 ${textPrimary}`}>{p.title}</h4>
              <p className={`text-sm ${textSecondary}`}>{p.desc}</p>
            </div>
          ))}
        </div>

        {/* Why Choose */}
        <div className="max-w-4xl mx-auto mb-20">
          <SectionHeader badge="Why Mahfuz" title="Why Work With Me" subtitle="What sets me apart from other growth agencies and freelancers in Web3." />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              "200+ successful projects delivered",
              "Direct access to 300+ exchange partners",
              "Network of 500+ KOLs globally",
              "1M+ community members managed",
              "Proven track record with data",
              "Dedicated team for each project",
              "Multilingual marketing (50+ countries)",
              "24/7 support and communication",
            ].map((item, i) => (
              <div key={i} className="flex items-center gap-3">
                <CheckCircle className="w-5 h-5 text-brand shrink-0" />
                <span className={`text-sm ${textSecondary}`}>{item}</span>
              </div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="text-center">
          <Link href="/contact" className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-brand to-secondary text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-brand/25 transition-all">
            Get Started <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </div>
  );
}
