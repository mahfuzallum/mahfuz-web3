export const SITE = {
  name: "Mahfuz",
  tagline: "Helping Web3 Projects Scale Through Marketing, Partnerships & Community.",
  description: "Web3 Growth Partner, KOL, Business Development Manager, Community Builder, Affiliate Marketer, and Content Creator. Driving growth for exchanges, blockchain startups and Web3 communities.",
  url: "https://mahfuz.io",
  telegram: "https://t.me/mahfuzallum",
  twitter: "https://x.com/mahfuzxallum",
  linkedin: "https://linkedin.com/in/mahfuz",
  email: "hello@mahfuz.io",
  calendly: "https://calendly.com/mahfuz",
};

export const SERVICES = [
  { title: "KOL Marketing", desc: "Leverage my network of 500K+ followers to amplify your project across Crypto Twitter and Telegram.", icon: "megaphone", stats: "500K+ Reach" },
  { title: "Business Development", desc: "Strategic partnerships with exchanges, launchpads, VCs and ecosystem partners.", icon: "handshake", stats: "100+ Partners" },
  { title: "Exchange Partnerships", desc: "Listing support on top-tier exchanges with full marketing and market-making coordination.", icon: "building", stats: "30+ Exchanges" },
  { title: "Community Growth", desc: "Build and manage vibrant communities across Telegram, Discord, and social platforms.", icon: "users", stats: "1M+ Members" },
  { title: "Telegram Marketing", desc: "Targeted campaigns, group management, bot integration, and engagement strategies.", icon: "send", stats: "200+ Groups" },
  { title: "Twitter/X Marketing", desc: "Content creation, thread campaigns, space hosting, and viral growth strategies.", icon: "twitter", stats: "50M+ Impressions" },
  { title: "Influencer Campaigns", desc: "Coordinate multi-influencer campaigns across platforms for maximum impact.", icon: "star", stats: "300+ KOLs" },
  { title: "AMA Management", desc: "Professional AMA sessions across Telegram, Twitter Spaces, and Discord.", icon: "mic", stats: "500+ AMAs" },
  { title: "Launch Campaigns", desc: "End-to-end launch campaigns for tokens, NFTs, and DeFi protocols.", icon: "rocket", stats: "150+ Launches" },
  { title: "Token Marketing", desc: "Comprehensive marketing for token launches, including pre and post-launch strategies.", icon: "coins", stats: "200+ Tokens" },
  { title: "Growth Consulting", desc: "Strategic advisory for Web3 projects on growth, marketing, and community building.", icon: "trendingUp", stats: "80+ Projects" },
  { title: "Content Strategy", desc: "Premium content creation including articles, threads, videos, and research reports.", icon: "penTool", stats: "1000+ Pieces" },
];

export const PORTFOLIO = [
  { name: "CryptoExchange Pro", category: "Exchange", goal: "Increase trading volume by 500%", result: "$2.5B+ trading volume generated", reach: "15M+", engagement: "850K+", feedback: "Mahfuz transformed our exchange's visibility. His strategic approach brought in thousands of new traders." },
  { name: "DeFi Protocol X", category: "DeFi", goal: "Launch with 50K TVL in first week", result: "$120M TVL achieved in first month", reach: "8M+", engagement: "420K+", feedback: "The launch campaign exceeded all our expectations. Professional, strategic, and results-driven." },
  { name: "GameFi Universe", category: "Gaming", goal: "Build community of 100K users", result: "500K+ active community members", reach: "25M+", engagement: "1.2M+", feedback: "Our community went from zero to half a million in just 3 months. Incredible growth partner." },
  { name: "Layer1 Chain", category: "Infrastructure", goal: "Mainnet launch awareness", result: "Top trending on all platforms", reach: "50M+", engagement: "3M+", feedback: "Mahfuz's network and strategy made our mainnet launch one of the most talked about events in crypto." },
  { name: "NFT Marketplace", category: "NFT", goal: "Drive 10K mints in first drop", result: "Sold out 25K NFTs in 2 hours", reach: "12M+", engagement: "600K+", feedback: "The NFT launch was a massive success thanks to Mahfuz's influencer network and community building." },
  { name: "Stablecoin Protocol", category: "DeFi", goal: "Achieve $1B market cap", result: "$3.5B market cap in 6 months", reach: "30M+", engagement: "1.5M+", feedback: "Strategic partnerships and KOL campaigns drove unprecedented adoption for our stablecoin." },
];

export const STATS = [
  { label: "Projects Completed", value: 200, suffix: "+" },
  { label: "Campaign Reach", value: 500, suffix: "M+" },
  { label: "Trading Volume", value: 10, suffix: "B+" },
  { label: "Communities Managed", value: 150, suffix: "+" },
  { label: "Partners", value: 300, suffix: "+" },
  { label: "Followers", value: 500, suffix: "K+" },
];

export const TESTIMONIALS = [
  { name: "Alex Chen", role: "CEO, CryptoExchange Pro", text: "Mahfuz is the best growth partner in Web3. His network and strategic thinking are unmatched.", rating: 5 },
  { name: "Sarah Kim", role: "CMO, DeFi Protocol X", text: "Working with Mahfuz transformed our project. The results speak for themselves — 120M TVL in month one.", rating: 5 },
  { name: "Michael Ross", role: "Founder, GameFi Universe", text: "From zero to 500K community members. Mahfuz delivers what he promises and more.", rating: 5 },
  { name: "Elena Volkov", role: "Head of BD, Layer1 Chain", text: "Professional, connected, and results-driven. The go-to person for Web3 growth.", rating: 5 },
];

export const NAV_LINKS = [
  { label: "Home", href: "/" },
  { label: "About", href: "/about" },
  { label: "Services", href: "/services" },
  { label: "Portfolio", href: "/portfolio" },
  { label: "Dashboard", href: "/dashboard" },
  { label: "Blog", href: "/blog" },
  { label: "Resources", href: "/resources" },
  { label: "Contact", href: "/contact" },
];

export const TRANSLATIONS: Record<string, Record<string, string>> = {
  en: {
    hero_title: "Helping Web3 Projects Grow Faster.",
    hero_sub: "Driving growth for exchanges, blockchain startups and Web3 communities through strategic partnerships, KOL marketing and premium content.",
    book_call: "Book a Call",
    view_portfolio: "View Portfolio",
    download_media: "Download Media Kit",
    services: "Services",
    portfolio: "Portfolio",
    about: "About",
    contact: "Contact",
    dashboard: "Dashboard",
    blog: "Blog",
    resources: "Resources",
  },
  bn: {
    hero_title: "ওয়েব৩ প্রজেক্ট দ্রুত বৃদ্ধিতে সাহায্য করি।",
    hero_sub: "কৌশলগত অংশীদারিত্ব, কেওএল মার্কেটিং এবং প্রিমিয়াম কন্টেন্টের মাধ্যমে এক্সচেঞ্জ, ব্লকচেইন স্টার্টআপ এবং ওয়েব৩ কমিউনিটির বৃদ্ধি চালনা করি।",
    book_call: "কল বুক করুন",
    view_portfolio: "পোর্টফোলিও দেখুন",
    download_media: "মিডিয়া কিট ডাউনলোড",
    services: "সেবাসমূহ",
    portfolio: "পোর্টফোলিও",
    about: "সম্পর্কে",
    contact: "যোগাযোগ",
    dashboard: "ড্যাশবোর্ড",
    blog: "ব্লগ",
    resources: "রিসোর্স",
  },
};
