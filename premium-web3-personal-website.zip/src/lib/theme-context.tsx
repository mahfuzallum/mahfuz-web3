"use client";
import { createContext, useContext, useState, useEffect, type ReactNode } from "react";

type Theme = "cyber" | "aurora";

interface ThemeCtx {
  theme: Theme;
  setTheme: (t: Theme) => void;
}

const Ctx = createContext<ThemeCtx>({ theme: "cyber", setTheme: () => {} });

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setTheme] = useState<Theme>("cyber");

  useEffect(() => {
    document.documentElement.classList.remove("theme-cyber", "theme-aurora");
    document.documentElement.classList.add(`theme-${theme}`);
  }, [theme]);

  return <Ctx.Provider value={{ theme, setTheme }}>{children}</Ctx.Provider>;
}

export function useTheme() {
  return useContext(Ctx);
}
