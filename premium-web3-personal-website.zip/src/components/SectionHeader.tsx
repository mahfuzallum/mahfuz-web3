"use client";
import { useTheme } from "@/lib/theme-context";

export default function SectionHeader({ badge, title, subtitle }: { badge: string; title: string; subtitle: string }) {
  const { theme } = useTheme();
  const isDark = theme === "cyber";
  return (
    <div className="text-center mb-16">
      <span className="inline-block px-4 py-1.5 rounded-full text-xs font-semibold tracking-wider uppercase bg-brand/10 text-brand border border-brand/20 mb-4">
        {badge}
      </span>
      <h2 className={`text-3xl md:text-4xl lg:text-5xl font-bold font-[family-name:var(--font-space)] mb-4 ${isDark ? "text-white" : "text-slate-900"}`}>
        {title}
      </h2>
      <p className={`max-w-2xl mx-auto text-lg ${isDark ? "text-gray-400" : "text-gray-600"}`}>
        {subtitle}
      </p>
    </div>
  );
}
