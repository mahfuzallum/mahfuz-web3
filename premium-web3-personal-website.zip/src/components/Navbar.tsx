"use client";
import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Menu, X, Globe, Sun, Moon } from "lucide-react";
import { NAV_LINKS } from "@/lib/constants";
import { useI18n } from "@/lib/i18n-context";
import { useTheme } from "@/lib/theme-context";

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const pathname = usePathname();
  const { lang, setLang } = useI18n();
  const { theme, setTheme } = useTheme();

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handler, { passive: true });
    return () => window.removeEventListener("scroll", handler);
  }, []);

  useEffect(() => { setOpen(false); }, [pathname]);

  const isDark = theme === "cyber";

  return (
    <>
      {/* Scroll progress */}
      <ScrollProgress />
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled
            ? isDark ? "glass shadow-lg shadow-brand/5" : "glass-light shadow-lg"
            : "bg-transparent"
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 lg:h-20">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-2 group">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-brand to-secondary flex items-center justify-center font-bold text-white text-lg font-[family-name:var(--font-space)]">
                M
              </div>
              <span className={`text-xl font-bold font-[family-name:var(--font-space)] ${isDark ? "text-white" : "text-slate-900"} group-hover:text-brand transition-colors`}>
                Mahfuz
              </span>
            </Link>

            {/* Desktop Nav */}
            <div className="hidden lg:flex items-center gap-1">
              {NAV_LINKS.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                    pathname === link.href
                      ? "text-brand bg-brand/10"
                      : isDark ? "text-gray-300 hover:text-white hover:bg-white/5" : "text-gray-600 hover:text-gray-900 hover:bg-gray-100"
                  }`}
                >
                  {link.label}
                </Link>
              ))}
            </div>

            {/* Controls */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => setLang(lang === "en" ? "bn" : "en")}
                className={`p-2 rounded-lg transition-colors ${isDark ? "text-gray-400 hover:text-white hover:bg-white/10" : "text-gray-500 hover:text-gray-900 hover:bg-gray-100"}`}
                title="Toggle Language"
              >
                <Globe className="w-5 h-5" />
              </button>
              <button
                onClick={() => setTheme(theme === "cyber" ? "aurora" : "cyber")}
                className={`p-2 rounded-lg transition-colors ${isDark ? "text-gray-400 hover:text-white hover:bg-white/10" : "text-gray-500 hover:text-gray-900 hover:bg-gray-100"}`}
                title="Toggle Theme"
              >
                {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </button>
              <Link
                href="/contact"
                className="hidden sm:inline-flex px-5 py-2.5 bg-gradient-to-r from-brand to-secondary text-white text-sm font-semibold rounded-xl hover:shadow-lg hover:shadow-brand/25 transition-all"
              >
                Let&apos;s Talk
              </Link>
              <button
                onClick={() => setOpen(!open)}
                className={`lg:hidden p-2 rounded-lg ${isDark ? "text-gray-400 hover:text-white" : "text-gray-500 hover:text-gray-900"}`}
              >
                {open ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {open && (
          <div className={`lg:hidden ${isDark ? "glass" : "glass-light"} border-t ${isDark ? "border-white/10" : "border-gray-200"}`}>
            <div className="px-4 py-4 space-y-1">
              {NAV_LINKS.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`block px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                    pathname === link.href
                      ? "text-brand bg-brand/10"
                      : isDark ? "text-gray-300 hover:text-white hover:bg-white/5" : "text-gray-600 hover:text-gray-900 hover:bg-gray-100"
                  }`}
                >
                  {link.label}
                </Link>
              ))}
              <Link
                href="/contact"
                className="block px-4 py-3 mt-2 bg-gradient-to-r from-brand to-secondary text-white text-sm font-semibold rounded-xl text-center"
              >
                Let&apos;s Talk
              </Link>
            </div>
          </div>
        )}
      </nav>
    </>
  );
}

function ScrollProgress() {
  const [progress, setProgress] = useState(0);
  useEffect(() => {
    const handler = () => {
      const winScroll = document.documentElement.scrollTop;
      const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
      setProgress(height > 0 ? (winScroll / height) * 100 : 0);
    };
    window.addEventListener("scroll", handler, { passive: true });
    return () => window.removeEventListener("scroll", handler);
  }, []);
  return (
    <div className="fixed top-0 left-0 right-0 z-[60] h-0.5">
      <div
        className="h-full bg-gradient-to-r from-brand to-secondary transition-all duration-150"
        style={{ width: `${progress}%` }}
      />
    </div>
  );
}
