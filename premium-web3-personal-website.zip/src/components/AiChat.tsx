"use client";
import { useState, useRef, useEffect } from "react";
import { MessageCircle, X, Send, Bot, User } from "lucide-react";

interface Message {
  role: "user" | "assistant";
  content: string;
}

const KNOWLEDGE = [
  { q: ["services", "what do you offer", "help", "marketing"], a: "Mahfuz offers comprehensive Web3 growth services including: KOL Marketing (500K+ reach), Business Development, Exchange Partnerships (30+ exchanges), Community Growth (1M+ members managed), Telegram & Twitter Marketing, Influencer Campaigns (300+ KOLs), AMA Management, Launch Campaigns, Token Marketing, Growth Consulting, and Content Strategy." },
  { q: ["price", "cost", "pricing", "rate", "budget"], a: "Pricing varies based on project scope and requirements. We offer flexible packages starting from consultation-based engagements to full-service growth partnerships. Please book a call or fill out the contact form for a customized quote." },
  { q: ["experience", "background", "about"], a: "Mahfuz is a seasoned Web3 Growth Partner with 200+ projects completed, 500M+ campaign reach, $10B+ trading volume generated, and 150+ communities managed. He works with exchanges, blockchain startups, DeFi protocols, and Web3 communities." },
  { q: ["contact", "reach", "call", "meet"], a: "You can reach Mahfuz through: Telegram (@mahfuzallum), Twitter/X (@mahfuzxallum), or book a call via the Contact page. Response time is typically within 24 hours." },
  { q: ["portfolio", "projects", "case study", "results"], a: "Mahfuz has worked with 200+ projects including major exchanges, DeFi protocols, GameFi platforms, and Layer 1 chains. Notable results include $2.5B+ trading volume for exchanges, $120M TVL for DeFi, and 500K+ community members for GameFi. Visit the Portfolio page for detailed case studies." },
  { q: ["telegram", "community", "group"], a: "Mahfuz manages 200+ Telegram groups and has built communities of 1M+ members. Services include group management, bot setup, engagement campaigns, and growth strategies. Check out the Telegram channel: t.me/mahfuzallum" },
  { q: ["exchange", "listing", "cex", "dex"], a: "Mahfuz has partnerships with 30+ exchanges and provides listing support including market making coordination, trading competitions, and post-listing marketing campaigns." },
  { q: ["hello", "hi", "hey", "good"], a: "Hello! 👋 Welcome to Mahfuz's website. I'm here to help answer questions about Web3 growth services, marketing, partnerships, and more. What would you like to know?" },
];

export default function AiChat() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { role: "assistant", content: "Hey! 👋 I'm Mahfuz's AI assistant. Ask me about services, pricing, experience, or anything else!" }
  ]);
  const [input, setInput] = useState("");
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const getResponse = (query: string): string => {
    const lower = query.toLowerCase();
    for (const item of KNOWLEDGE) {
      if (item.q.some(k => lower.includes(k))) return item.a;
    }
    return "Thanks for your question! For specific inquiries, I'd recommend booking a call with Mahfuz directly through the Contact page, or reaching out via Telegram @mahfuzallum. Is there anything else about our Web3 growth services I can help with?";
  };

  const send = () => {
    if (!input.trim()) return;
    const userMsg: Message = { role: "user", content: input };
    setMessages(prev => [...prev, userMsg]);
    setInput("");
    setTimeout(() => {
      const response = getResponse(input);
      setMessages(prev => [...prev, { role: "assistant", content: response }]);
    }, 500);
  };

  return (
    <>
      <button
        onClick={() => setOpen(!open)}
        className="fixed bottom-6 right-6 z-50 w-14 h-14 bg-gradient-to-r from-brand to-secondary text-white rounded-full flex items-center justify-center shadow-lg shadow-brand/30 hover:shadow-brand/50 transition-all hover:scale-110"
      >
        {open ? <X className="w-6 h-6" /> : <MessageCircle className="w-6 h-6" />}
      </button>

      {open && (
        <div className="fixed bottom-24 right-6 z-50 w-[360px] max-w-[calc(100vw-3rem)] glass rounded-2xl shadow-2xl overflow-hidden flex flex-col" style={{ height: "480px" }}>
          <div className="p-4 bg-gradient-to-r from-brand to-secondary">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                <Bot className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-white font-semibold text-sm">Mahfuz AI Assistant</p>
                <p className="text-white/70 text-xs">Always online • Instant replies</p>
              </div>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {messages.map((m, i) => (
              <div key={i} className={`flex gap-2 ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                {m.role === "assistant" && (
                  <div className="w-7 h-7 rounded-full bg-brand/20 flex items-center justify-center shrink-0 mt-1">
                    <Bot className="w-3.5 h-3.5 text-brand" />
                  </div>
                )}
                <div className={`max-w-[80%] px-3 py-2 rounded-2xl text-sm ${
                  m.role === "user"
                    ? "bg-brand text-black rounded-br-sm"
                    : "bg-white/10 text-gray-200 rounded-bl-sm"
                }`}>
                  {m.content}
                </div>
                {m.role === "user" && (
                  <div className="w-7 h-7 rounded-full bg-secondary/20 flex items-center justify-center shrink-0 mt-1">
                    <User className="w-3.5 h-3.5 text-secondary" />
                  </div>
                )}
              </div>
            ))}
            <div ref={endRef} />
          </div>

          <div className="p-3 border-t border-white/10">
            <div className="flex gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && send()}
                placeholder="Ask me anything..."
                className="flex-1 px-3 py-2 bg-white/5 border border-white/10 rounded-xl text-sm text-white placeholder:text-gray-500 focus:outline-none focus:ring-1 focus:ring-brand/50"
              />
              <button onClick={send} className="p-2 bg-brand text-black rounded-xl hover:bg-brand-dark transition-colors">
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
