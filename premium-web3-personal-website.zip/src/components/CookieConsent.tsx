"use client";
import { useState, useEffect } from "react";
import { X } from "lucide-react";

export default function CookieConsent() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const accepted = localStorage.getItem("cookie_consent");
    if (!accepted) setTimeout(() => setShow(true), 2000);
  }, []);

  const accept = () => {
    localStorage.setItem("cookie_consent", "true");
    setShow(false);
  };

  if (!show) return null;

  return (
    <div className="fixed bottom-4 left-4 right-4 md:left-auto md:right-6 md:max-w-md z-50 glass rounded-2xl p-6 shadow-2xl animate-[slideUp_0.5s_ease]">
      <button onClick={() => setShow(false)} className="absolute top-3 right-3 text-gray-400 hover:text-white">
        <X className="w-4 h-4" />
      </button>
      <p className="text-white text-sm font-semibold mb-1">🍪 Cookie Notice</p>
      <p className="text-gray-400 text-sm mb-4">
        We use cookies to enhance your experience. By continuing, you agree to our cookie policy.
      </p>
      <div className="flex gap-3">
        <button onClick={accept} className="px-4 py-2 bg-brand text-black text-sm font-semibold rounded-lg hover:bg-brand-dark transition-colors">
          Accept
        </button>
        <button onClick={() => setShow(false)} className="px-4 py-2 bg-white/10 text-white text-sm rounded-lg hover:bg-white/20 transition-colors">
          Decline
        </button>
      </div>
    </div>
  );
}
