"use client";
import Link from "next/link";
import { Send, Mail, ExternalLink, Heart } from "lucide-react";

function XIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>;
}
function LinkedInIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="currentColor"><path d="M20.5 2h-17A1.5 1.5 0 002 3.5v17A1.5 1.5 0 003.5 22h17a1.5 1.5 0 001.5-1.5v-17A1.5 1.5 0 0020.5 2zM8 19H5v-9h3zM6.5 8.25A1.75 1.75 0 118.3 6.5a1.78 1.78 0 01-1.8 1.75zM19 19h-3v-4.74c0-1.42-.6-1.93-1.38-1.93A1.74 1.74 0 0013 14.19a.66.66 0 000 .14V19h-3v-9h2.9v1.3a3.11 3.11 0 012.7-1.4c1.55 0 3.36.86 3.36 3.66z"/></svg>;
}
import { SITE } from "@/lib/constants";
import { useTheme } from "@/lib/theme-context";
import { useState } from "react";

export default function Footer() {
  const { theme } = useTheme();
  const isDark = theme === "cyber";
  const [email, setEmail] = useState("");
  const [subbed, setSubbed] = useState(false);

  const subscribe = async () => {
    if (!email) return;
    try {
      await fetch("/api/newsletter", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email }) });
      setSubbed(true);
      setEmail("");
    } catch { /* noop */ }
  };

  return (
    <footer className={`relative ${isDark ? "bg-bg-dark border-t border-white/5" : "bg-white border-t border-gray-200"}`}>
      {/* Newsletter Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="gradient-border rounded-2xl p-8 md:p-12 text-center mb-16">
          <h3 className={`text-2xl md:text-3xl font-bold font-[family-name:var(--font-space)] mb-4 ${isDark ? "text-white" : "text-slate-900"}`}>
            Stay Ahead in Web3
          </h3>
          <p className={`mb-6 max-w-lg mx-auto ${isDark ? "text-gray-400" : "text-gray-600"}`}>
            Get weekly insights on crypto markets, growth strategies, and exclusive opportunities.
          </p>
          {subbed ? (
            <p className="text-brand font-semibold">✓ Subscribed successfully!</p>
          ) : (
            <div className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email"
                className={`flex-1 px-4 py-3 rounded-xl border ${isDark ? "bg-white/5 border-white/10 text-white placeholder:text-gray-500" : "bg-gray-50 border-gray-200 text-gray-900 placeholder:text-gray-400"} focus:outline-none focus:ring-2 focus:ring-brand/50`}
              />
              <button onClick={subscribe} className="px-6 py-3 bg-gradient-to-r from-brand to-secondary text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-brand/25 transition-all">
                Subscribe
              </button>
            </div>
          )}
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-brand to-secondary flex items-center justify-center font-bold text-white text-sm">M</div>
              <span className={`font-bold font-[family-name:var(--font-space)] ${isDark ? "text-white" : "text-slate-900"}`}>Mahfuz</span>
            </div>
            <p className={`text-sm ${isDark ? "text-gray-500" : "text-gray-500"}`}>
              Your trusted Web3 Growth Partner for marketing, partnerships & community.
            </p>
          </div>
          <div>
            <h4 className={`font-semibold mb-4 ${isDark ? "text-white" : "text-slate-900"}`}>Pages</h4>
            <div className="space-y-2">
              {["About", "Services", "Portfolio", "Blog", "Contact"].map((l) => (
                <Link key={l} href={`/${l.toLowerCase()}`} className={`block text-sm ${isDark ? "text-gray-400 hover:text-brand" : "text-gray-500 hover:text-brand"} transition-colors`}>
                  {l}
                </Link>
              ))}
            </div>
          </div>
          <div>
            <h4 className={`font-semibold mb-4 ${isDark ? "text-white" : "text-slate-900"}`}>Resources</h4>
            <div className="space-y-2">
              {["Dashboard", "Resources", "Media Kit", "Case Studies"].map((l) => (
                <Link key={l} href={`/${l.toLowerCase().replace(/\s+/g, "-")}`} className={`block text-sm ${isDark ? "text-gray-400 hover:text-brand" : "text-gray-500 hover:text-brand"} transition-colors`}>
                  {l}
                </Link>
              ))}
            </div>
          </div>
          <div>
            <h4 className={`font-semibold mb-4 ${isDark ? "text-white" : "text-slate-900"}`}>Connect</h4>
            <div className="flex gap-3">
              {[
                { icon: <Send className="w-4 h-4" />, href: SITE.telegram },
                { icon: <XIcon className="w-4 h-4" />, href: SITE.twitter },
                { icon: <LinkedInIcon className="w-4 h-4" />, href: SITE.linkedin },
                { icon: <Mail className="w-4 h-4" />, href: `mailto:${SITE.email}` },
              ].map((s, i) => (
                <a key={i} href={s.href} target="_blank" rel="noopener noreferrer" className={`p-2.5 rounded-xl ${isDark ? "bg-white/5 hover:bg-brand/20 text-gray-400 hover:text-brand" : "bg-gray-100 hover:bg-brand/10 text-gray-500 hover:text-brand"} transition-all`}>
                  {s.icon}
                </a>
              ))}
            </div>
          </div>
        </div>

        <div className={`pt-8 border-t ${isDark ? "border-white/5" : "border-gray-200"} flex flex-col sm:flex-row items-center justify-between gap-4`}>
          <p className={`text-sm ${isDark ? "text-gray-500" : "text-gray-400"}`}>
            © {new Date().getFullYear()} Mahfuz. All rights reserved.
          </p>
          <div className="flex gap-4">
            <Link href="/privacy" className={`text-sm ${isDark ? "text-gray-500 hover:text-brand" : "text-gray-400 hover:text-brand"} transition-colors`}>Privacy</Link>
            <Link href="/terms" className={`text-sm ${isDark ? "text-gray-500 hover:text-brand" : "text-gray-400 hover:text-brand"} transition-colors`}>Terms</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
